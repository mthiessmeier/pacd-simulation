"""Verify the accepted two-parent merge without relying on a moving remote ref."""
import subprocess

INCREMENT5_MAIN = "9c9dfcec659870c41aa7cc95846d6760d9c31df7"
REVIEWED_HEAD = "9f58a43021eb1efe159a55b4540e0e872b963349"
IMPLEMENTATION = "5eb554c21b008038ecc50d0f7433977bef64ba7a"
APPROVED_TREE = "b8f84815f15aee2473ea2150820497777eb541b6"


def validate_main(repo, head):
    def git(*args):
        return subprocess.check_output(["git",*args],text=True,cwd=repo).strip()
    assert __debug__ and git("rev-parse","HEAD") == head and not git("status","--porcelain")
    assert git("show","-s","--format=%P",head).split() == [INCREMENT5_MAIN, REVIEWED_HEAD]
    assert git("rev-parse",head+"^{tree}") == git("rev-parse",REVIEWED_HEAD+"^{tree}") == APPROVED_TREE
    assert git("rev-parse",REVIEWED_HEAD+"^") == IMPLEMENTATION
    assert git("diff","--name-only",IMPLEMENTATION,head) == "README.md"
    return {"accepted_main":head,"first_parent":INCREMENT5_MAIN,"second_parent":REVIEWED_HEAD,
            "implementation_pin":IMPLEMENTATION,"tree":APPROVED_TREE}
