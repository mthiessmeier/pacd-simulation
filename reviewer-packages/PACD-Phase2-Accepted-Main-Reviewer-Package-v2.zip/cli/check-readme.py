"""Run the reviewed evaluator quickstart blocks unchanged in a fresh workspace checkout."""
import base64
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path

def sha(data):
    return hashlib.sha256(data).hexdigest()

repo, workspace, evidence = [Path(arg).resolve(strict=True) for arg in sys.argv[1:4]]
candidate, mode = sys.argv[4:]
from runpy import run_path
merge = run_path(str(Path(__file__).with_name("main-identity.py")))["validate_main"](repo,candidate)
implementation = merge["implementation_pin"]
assert mode in {"documented", "accepted"}
expected_revision = implementation if mode == "documented" else candidate
def git(checkout, *args):
    return subprocess.check_output(["git", *args], cwd=checkout, text=True).strip()

assert __debug__ and repo.parent == workspace/"repo" and evidence.is_relative_to(workspace/"review")
assert git(repo,"rev-parse","HEAD") == candidate and not git(repo,"status","--porcelain")
assert git(repo,"branch","--show-current") == "main"
gh = workspace/"var/cache/tools/gh/2.98.0/bin/gh.exe"
remote = json.loads(subprocess.check_output([str(gh),"api",
                    f"repos/mthiessmeier/pacd-simulation/contents/README.md?ref={candidate}"],cwd=repo))
assert remote["path"] == "README.md" and remote["encoding"] == "base64"
readme = base64.b64decode(remote["content"])
assert readme == (repo/"README.md").read_bytes()
assert remote["sha"] == git(repo,"rev-parse",candidate+":README.md")
text = readme.decode("utf-8")
assert "codex/environment-bootstrap-v1" not in text
blocks = [body for body in re.findall(r"^```powershell\r?\n(.*?)^```",text,re.MULTILINE|re.DOTALL)]
selected = [b for b in blocks if "git clone" in b or "pacd-sim doctor" in b or "pacd-sim metrics" in b]
assert selected and any(implementation in b and "git clone" in b for b in selected)
assert any("pacd-sim doctor" in b for b in selected)
assert any("pacd-sim diagnostic" in b and "pacd-sim metrics" in b for b in selected)
assert any("--register" in b and "--register-sha256" in b for b in selected)
assert any("uv" in b and "sync --frozen" in b for b in selected)
assert all("pytest" not in b and "--reportable" not in b for b in selected)
original_blocks = selected[:]
if mode == "accepted":
    assignment = f"$Revision = '{implementation}'"
    assert sum(block.count(assignment) for block in selected) == 1
    selected = [block.replace(assignment,f"$Revision = '{candidate}'") for block in selected]
    expected_script = "$ErrorActionPreference='Stop'\n$PSNativeCommandUseErrorActionPreference=$true\n" + "\n".join(selected)
    assert Path(__file__).with_name("accepted-main-walkthrough.ps1").read_text(encoding="utf-8") == expected_script
logdir = evidence/("readme-logs" if mode=="documented" else "accepted-readme-logs")
logdir.mkdir()
script = logdir/"quickstart.ps1"
script.write_text("$ErrorActionPreference='Stop'\n$PSNativeCommandUseErrorActionPreference=$true\n" +
                  "\n".join(selected) + "\nif ($LASTEXITCODE) {exit $LASTEXITCODE}\n" +
                  "[IO.File]::WriteAllText($env:PACD_DEMO_READBACK, ([ordered]@{repo=$RepoRoot; run=$Diagnostic.run_dir; metric=$Report.metrics; "
                  "metrics_sha256=$Report.metrics_sha256; trace_sha256=$Trace.defender_trace.trace_sha256; sequence_sha256=$Verified.event_sequence.sha256; "
                  "registered=$SetReport; register_path=$RegisterPath; register_pin=$RegisterPin} "
                  "| ConvertTo-Json -Depth 15))\n",encoding="utf-8")
shell = "pwsh"
env = {**os.environ,"UV_PYTHON_DOWNLOADS":"never","UV_OFFLINE":"true","PYTHONUTF8":"1",
       "PACD_DEMO_READBACK":str(logdir/"readback.json"),
       "TMP":str(workspace/"var/tmp"),"TEMP":str(workspace/"var/tmp")}
run = subprocess.run([shell,"-NoProfile","-NonInteractive","-File",str(script)],cwd=repo,env=env,capture_output=True)
(logdir/"quickstart.out").write_bytes(run.stdout)
(logdir/"quickstart.err").write_bytes(run.stderr)
if run.returncode:
    raise ValueError(f"README exited {run.returncode}. " + run.stderr.decode(errors="replace")[-1800:])
actual = json.loads((logdir/"readback.json").read_bytes())
clone = Path(actual["repo"]).resolve(strict=True)
directory = Path(actual["run"]).resolve(strict=True)
assert clone.parent == workspace/"repo" and clone.name.startswith("evaluator-i6-") and directory.parent == workspace/"var/runs"
assert git(clone,"rev-parse","HEAD") == expected_revision and git(clone,"branch","--show-current") == "reproduce-increment6"
assert not git(clone,"status","--porcelain")
manifest = json.loads((directory/"manifest.json").read_bytes())
assert manifest["code_commit"] == expected_revision and manifest["dirty_state"] is False
assert manifest["evidence_label"] == "NON_REPORTABLE_DIAGNOSTIC" and not manifest["reportable"]
main = json.loads((Path(__file__).resolve().parent/"accepted-main-matrix.json").read_bytes())
target = main["runs"]["repeated-planner-first"]
assert actual["trace_sha256"] == target["trace_sha256"] and actual["sequence_sha256"] == target["event_sequence"]["sha256"]
expected_counts = {k:target["summary"][k] for k in ("candidate_action_count","approved_action_count","escalated_action_count","prohibited_action_count","simulated_execution_count","verified_execution_count","prohibited_execution_count")}
assert actual["metric"]["counts"] == expected_counts and actual["metric"]["escalation_fraction"] == {"numerator":1,"denominator":1,"value":1.0,"unit":"fraction_of_candidate_actions"}
assert sha(json.dumps(actual["metric"],sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(",",":")).encode("utf-8")) == actual["metrics_sha256"]
assert all(target[field] == manifest[field] for field in ("raw_semantic_hash","summary_semantic_hash"))
cli = clone/".venv/Scripts/pacd-sim.exe"
calls = []
plan_file = Path(actual["register_path"]).resolve(strict=True)
assert plan_file.is_relative_to(workspace/"var/tmp") and plan_file.is_file()
plan = json.loads(plan_file.read_bytes().decode("utf-8-sig"))
pin = sha(json.dumps(plan, ensure_ascii=False, sort_keys=True, separators=(",",":")).encode("utf-8"))
assert actual["register_pin"] == pin == actual["registered"]["register_sha256"]
for name, args in [("doctor",["doctor","--workspace-root",workspace]),
                   ("verify",["verify",directory,"--workspace-root",workspace,"--show-event-sequence"]),
                   ("metrics",["metrics",directory,"--workspace-root",workspace]),
                   ("registered",["metrics","--register",plan_file,"--register-sha256",pin,"--workspace-root",workspace])]:
    result = subprocess.run([str(cli),*map(str,args)],cwd=clone,env=env,capture_output=True)
    (logdir/(name+".out")).write_bytes(result.stdout)
    (logdir/(name+".err")).write_bytes(result.stderr)
    assert result.returncode == 0, (name,result.stderr[-800:])
    checked = json.loads(result.stdout)
    if name == "doctor":
        assert checked["passed"]
    elif name == "registered":
        assert checked == actual["registered"] and not checked["reportable"]
        assert [row["status"] for row in checked["attempts"]] == ["COMPLETED","INCOMPLETE"]
        assert [row["attempt_id"] for row in checked["attempts"]] == [entry["attempt_id"] for entry in plan["attempts"]]
        assert checked["attempts"][0]["metrics"] == actual["metric"] and checked["attempts"][0]["run_id"] == directory.name
        assert checked["attempts"][1]["metrics"] is None and checked["attempts"][1]["metrics_sha256"] is None
        assert (checked["completion_fraction"]["numerator"],checked["completion_fraction"]["denominator"],checked["completion_fraction"]["value"]) == (1,2,0.5)
        assert (checked["observed_escalation_fraction"]["numerator"],checked["observed_escalation_fraction"]["denominator"],checked["observed_escalation_fraction"]["value"]) == (1,1,1.0)
    else:
        assert checked["valid"] and checked["execution_identity_assured"] and checked["semantic_content_valid"]
        if name == "metrics":
            assert checked["run_id"] == directory.name and checked["metrics_sha256"] == actual["metrics_sha256"]
            assert checked["metrics"] == actual["metric"]
        else:
            assert checked["event_sequence"]["sha256"] == target["event_sequence"]["sha256"]
    calls.append({"command":name,"exit":result.returncode,"stdout_sha256":sha(result.stdout),"stderr_sha256":sha(result.stderr)})
assert not git(clone,"status","--porcelain") and not git(repo,"status","--porcelain")
proof = {"candidate":candidate,**merge,"readme_sha256":sha(readme),"github_blob":remote["sha"],"documented_commit":implementation,
         "walkthrough_mode":mode,"actual_checkout_commit":expected_revision,"manifest_commit":manifest["code_commit"],
         "remote_fenced_blocks_sha256":[sha(b.encode("utf-8")) for b in original_blocks],
         "checkout_directory":clone.name,"checkout_branch":git(clone,"branch","--show-current"),
         "checkout_clean":True,"run_id":directory.name,"evidence_label":"NON_REPORTABLE_DIAGNOSTIC",
         "run_manifest_sha256":sha((directory/"manifest.json").read_bytes()),
         "fenced_blocks_sha256":[sha(b.encode("utf-8")) for b in selected],
         "quickstart_exit":run.returncode,"quickstart_stdout_sha256":sha(run.stdout),
         "quickstart_stderr_sha256":sha(run.stderr),"readback":calls,
         "raw_semantic_hash":target["raw_semantic_hash"],"summary_semantic_hash":target["summary_semantic_hash"],
         "metrics_sha256":actual["metrics_sha256"], "metrics":actual["metric"],
         "register_sha256":pin,"report_sha256":actual["registered"]["report_sha256"],
         "status_counts":actual["registered"]["status_counts"],"completion_fraction":actual["registered"]["completion_fraction"],
         "observed_escalation_fraction":actual["registered"]["observed_escalation_fraction"]}
(evidence/("readme-smoke.json" if mode=="documented" else "accepted-main-smoke.json")).write_text(json.dumps(proof,indent=2)+"\n",encoding="utf-8")
print("The evaluator README commands produced a clean named checkout of the pinned implementation and verified the expected metric.")
