"""Verify the public Increment 6 episode metric on fresh runs from the accepted 19-case matrix."""
import hashlib
import json
import subprocess
import sys
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

import pyarrow.parquet as pq


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(value):
    return sha(json.dumps(value, separators=(",", ":"), sort_keys=True, allow_nan=False,
                          ensure_ascii=False).encode("utf-8"))


def read(path):
    return json.loads(path.read_bytes())


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")


def inventory():
    return json.loads(subprocess.check_output([sys.executable, "-B", str(packet/"store-inventory.py"),
                                               str(workspace)], cwd=repo))


def invoke(label, exe, *args):
    start = datetime.now(UTC).isoformat()
    run = subprocess.run([str(exe), *map(str, args)], cwd=repo, capture_output=True)
    (logs/(label+".out")).write_bytes(run.stdout)
    (logs/(label+".err")).write_bytes(run.stderr)
    calls.append({
        "name":label, "tool":Path(exe).stem, "commit":head,
        "arguments":[str(a).replace(str(workspace), "<workspace>") for a in args],
        "start_utc":start, "end_utc":datetime.now(UTC).isoformat(), "exit":run.returncode,
        "stdout_sha256":sha(run.stdout), "stderr_sha256":sha(run.stderr),
    })
    save(evidence/"commands.json", calls)
    if run.returncode:
        raise ValueError(label+" failed: "+(run.stderr or run.stdout).decode(errors="replace")[-1600:])
    return json.loads(run.stdout)


def expected_metrics(rows, seed, config_hash):
    kinds = Counter(r["event_type"] for r in rows)
    safety = {r["action_id"]:r["disposition"] for r in rows if r["event_type"] == "safety_decision"}
    by_disposition = Counter(safety.values())
    verified = [r for r in rows if r["event_type"] == "verification" and r["outcome"] == "verified"]
    prohibited_executions = [r for r in rows if r["event_type"] == "simulated_execution" and safety[r["action_id"]] == "PROHIBIT"]
    assert len(safety) == kinds["safety_decision"] == kinds["candidate_action"]
    counts = {
        "candidate_action_count":kinds["candidate_action"], "approved_action_count":by_disposition["APPROVE"],
        "escalated_action_count":by_disposition["ESCALATE"], "prohibited_action_count":by_disposition["PROHIBIT"],
        "simulated_execution_count":kinds["simulated_execution"], "verified_execution_count":len(verified),
        "prohibited_execution_count":len(prohibited_executions),
    }
    num, den = counts["escalated_action_count"], counts["candidate_action_count"]
    return {"format":"pacd-episode-dispositions-v1","completion_status":"EVENT_CHAIN_COMPLETED" if kinds["manifest"] else "INCOMPLETE",
            "seed":seed,"config_hash":config_hash,"counts":counts,
            "escalation_fraction":{"numerator":num,"denominator":den,"unit":"fraction_of_candidate_actions",
                                   "value":num/den if den else None}}


def check_source(key, reference):
    fixture, condition, _ = key.split("-")
    seed = reference["seed"]
    run = invoke(key+"-run", cli, "diagnostic", "--workspace-root",workspace, "--seed",seed,
                 "--scenario","configs/scenarios/"+scenes[fixture],"--baseline","configs/defenders/"+modes[condition])
    path = Path(run["run_dir"]).resolve(strict=True)
    assert path.parent == workspace/"var/runs" and path.name == run["run_id"] != reference["run_id"]
    verified = invoke(key+"-verify",cli,"verify",path,"--workspace-root",workspace,"--show-event-sequence")
    trace = invoke(key+"-defender",cli,"defender-trace",path,"--workspace-root",workspace)
    rebuilt = invoke(key+"-regenerate",sys.executable,"docs/application_demo/regenerate.py",path)
    manifest = read(path/"manifest.json")
    assert manifest["code_commit"] == head and manifest["dirty_state"] is False
    assert manifest["evidence_label"] == "NON_REPORTABLE_DIAGNOSTIC" and not manifest["reportable"]
    assert run["config_hash"] == manifest["config_hash_start"] == manifest["config_hash_end"] == reference["config_hash"]
    for report in (verified, trace):
        assert report["valid"] and report["execution_identity_assured"] and report["semantic_content_valid"]
        assert not report["reportable"] and report["errors"] == [] and report["status"] == "VERIFIED"
        for field in ("raw_semantic_hash","summary_semantic_hash"):
            assert reference[field] == report[field] == run[field] == manifest[field]
    assert verified["event_sequence"] == reference["event_sequence"]
    assert trace["defender_trace"]["trace_sha256"] == reference["trace_sha256"]
    records = [json.loads(line) for line in (path/"raw/events.jsonl").read_bytes().splitlines()]
    assert records == pq.read_table(path/"raw/events.parquet").to_pylist()
    summary, = pq.read_table(path/"derived/episode_summary.parquet").to_pylist()
    assert rebuilt["summary"] == summary == reference["summary"]
    assert rebuilt["sha256"] == reference["regenerated_sha256"]
    for filename, fingerprint in rebuilt["sha256"].items():
        assert sha((path/"derived"/filename).read_bytes()) == sha((Path(rebuilt["directory"])/filename).read_bytes()) == fingerprint
    public = expected_metrics(records,seed,run["config_hash"])
    assert {name:summary[name] for name in public["counts"]} == public["counts"]
    return {"run_id":run["run_id"],"manifest_sha256":sha((path/"manifest.json").read_bytes()),
            "raw_semantic_hash":run["raw_semantic_hash"],"summary_semantic_hash":run["summary_semantic_hash"],
            "source_sequence_sha256":verified["event_sequence"]["sha256"],"trace_sha256":reference["trace_sha256"],
            "regenerated_sha256":rebuilt["sha256"],"metrics":public}


def check_metric(key,case):
    run = workspace/"var/runs"/case["run_id"]
    outputs = []
    for read_number in (1,2):
        report = invoke(f"{key}-metrics-{read_number}",cli,"metrics",run,"--workspace-root",workspace)
        assert report["status"] == "VERIFIED" and report["valid"] and report["semantic_content_valid"] and report["execution_identity_assured"]
        assert report["evidence_label"] == "NON_REPORTABLE_DIAGNOSTIC" and not report["reportable"]
        assert report["run_id"] == case["run_id"] and report["errors"] == []
        assert report["raw_semantic_hash"] == case["raw_semantic_hash"] and report["summary_semantic_hash"] == case["summary_semantic_hash"]
        assert report["metrics"] == case["metrics"]
        assert report["metrics_sha256"] == digest(case["metrics"])
        outputs.append(calls[-1]["stdout_sha256"])
    assert outputs[0] == outputs[1]
    case.update(metrics_sha256=report["metrics_sha256"],repeated_stdout_sha256=outputs[0])


assert __debug__
repo, workspace, evidence = [Path(x).resolve(strict=True) for x in sys.argv[1:4]]
head = sys.argv[4]
assert repo.parent == workspace/"repo" and evidence.is_relative_to(workspace/"review")
def git(*args):
    return subprocess.check_output(["git",*args],cwd=repo,text=True).strip()
from runpy import run_path
merge = run_path(str(Path(__file__).with_name("main-identity.py")))["validate_main"](repo,head)
assert git("branch","--show-current") == "main"
assert not git("status","--porcelain")
packet = Path(__file__).resolve().parent
reference_file = packet / "accepted-main-matrix.json"
assert sha(reference_file.read_bytes()) == "034cddbb67a2842ca3fa14976ed7605cfc80a07aef0b930030e2aafaa317d526"
reference = read(reference_file)
assert reference["candidate"] == "9c9dfcec659870c41aa7cc95846d6760d9c31df7" and reference["all_approved_semantics_reproduced"]
assert git("merge-base",head,reference["candidate"]) == reference["candidate"]
logs = evidence/"logs"
logs.mkdir()
calls = []
cli = repo/".venv/Scripts/pacd-sim.exe"
scenes = {"smoke":"diagnostic_identity_smoke.yaml", "maintenance":"diagnostic_maintenance_window.yaml",
          "repeated":"diagnostic_repeated_readings.yaml"}
modes = {"planner":"pacd_corroborated_review.yaml","static":"static_review.yaml","legacy":"diagnostic_baseline.yaml"}
cases = {key: check_source(key, row) for key,row in reference["runs"].items()}
assert len({r["run_id"] for r in cases.values()}) == len(cases) == 19
before = inventory()
for key, case in cases.items():
    check_metric(key,case)
after = inventory()
assert before == after
for fixture in scenes:
    assert cases[fixture+"-planner-first"]["metrics_sha256"] == cases[fixture+"-planner-repeat"]["metrics_sha256"]
ratios = {(r["metrics"]["escalation_fraction"]["numerator"],r["metrics"]["escalation_fraction"]["denominator"]) for r in cases.values()}
assert ratios == {(0,0),(1,1),(4,4),(1,3)}
assert len(calls) == 114 and not git("status","--porcelain")
for call in calls:
    assert call["exit"] == 0
    for stream,ext in (("stdout","out"),("stderr","err")):
        assert sha((logs/(call["name"]+"."+ext)).read_bytes()) == call[stream+"_sha256"]
fields = ("raw_semantic_hash","summary_semantic_hash","source_sequence_sha256","trace_sha256","regenerated_sha256","metrics_sha256")
semantics = {k:{field:v[field] for field in fields} for k,v in cases.items()}
assert digest(semantics) == "9cc6fc7be339f6bc6e944f01d060ca99d2680f17d5eeabf2e972a5689f9f70fb"
save(evidence/"matrix.json", {"candidate":head, **merge, "reference_main":reference["candidate"],
      "approved_pr_semantic_digest":digest(semantics),
      "evidence_label":"NON_REPORTABLE_DIAGNOSTIC","all_accepted_hashes_matched":True,"command_count":len(calls),
      "unchanged_retained_stores":True,"before":before,"after":after,"runs":cases})
lines = ["# Verified episode disposition metrics", "",
         "All 19 runs on accepted main matched the prior verified results on raw and summary semantics, event sequence, defender trace and regenerated outputs. "
         "The metric values below were independently computed from each retained audit row.", "",
         "| Source | Seed | Invocation | Escalations | Candidates | Fraction | Simulated executions | Metric SHA-256 prefix |",
         "| --- | ---: | --- | ---: | ---: | --- | ---: | --- |"]
for key,case in cases.items():
    fixture, condition, repeat = key.split("-")
    m = case["metrics"]
    f = m["escalation_fraction"]
    value = f["value"] if f["value"] is not None else "undefined"
    lines.append(f"| {fixture} / {condition} | {m['seed']} | {repeat} | {f['numerator']} | {f['denominator']} | "
                 f"{value} | {m['counts']['simulated_execution_count']} | `{case['metrics_sha256'][:12]}` |")
lines += ["","All 38 metric invocations verified the receipt and matched the independent counts, ratio and public digest. "
          "Two reads of each retained run returned identical bytes. The retained data and metadata fingerprints before and after those reads also matched. "
          "These are non-reportable synthetic episode descriptors. "
          "The [matrix](matrix.json) records complete metrics, semantic hashes and run IDs. "
          "The [command ledger](commands.json) records all 114 exits and 228 output digests."]
(evidence/"matrix.md").write_text("\n".join(lines)+"\n", encoding="utf-8")
print(f"Verified all 114 commands. Matrix SHA-256 {sha((evidence/'matrix.json').read_bytes())}.")
