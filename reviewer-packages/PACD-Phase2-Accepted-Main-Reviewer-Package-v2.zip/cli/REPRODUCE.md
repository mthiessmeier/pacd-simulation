# Reproduce the accepted Phase 2 CLI results

## Evaluator walkthrough

From the extracted reviewer package, run the following PowerShell command. It clones the private repository, creates a named local branch at accepted main `d5a29699e14409bfd54d30c51117c81077639ee6`, reconstructs the frozen environment and runs the two-attempt demonstration. It uses the existing project toolchain and package cache in the designated PACD workspace. The console prints the planner decisions, episode metrics, attempt statuses and the two fractions. The exact-main script uses the two README command blocks with the revision assignment set to the merge. [Runnable walkthrough](accepted-main-walkthrough.ps1) · [Exact-main receipt](accepted-main-smoke.json)

```powershell
pwsh -NoProfile -File .\cli\accepted-main-walkthrough.ps1
```

## Full CLI replay

For the full set below, use a clean checkout on the local `main` branch at the merge SHA inside the designated workspace’s `repo` directory. Set `$packet` to the extracted packet’s `cli` directory. The checker verifies the two merge parents and equality with the approved PR tree. Run the gate-denial probes before the CLI replay. Complete both walkthroughs before running the command below, or run them after replay has finished. The read-only checks fingerprint the shared stores and require other producers to be idle.

```powershell
$workspace = Join-Path $env:USERPROFILE 'PACD-Workspaces/PACD-Simulation'
$checkout = (Resolve-Path '.').Path
$uv = Join-Path $workspace 'var/cache/tools/uv/0.12.5/uv.exe'
$env:PATH = (Split-Path -Parent $uv) + ';' + $env:PATH
$env:UV_CACHE_DIR = Join-Path $workspace 'var/cache/uv-project'
$env:UV_PYTHON_DOWNLOADS = 'never'
$env:UV_OFFLINE = 'true'
$env:TEMP = Join-Path $workspace 'var/tmp'
$env:TMP = $env:TEMP
& $uv sync --frozen --offline --python 3.13.15
if ($LASTEXITCODE) { throw 'Frozen environment setup failed' }
$head = (Get-Content -Raw (Join-Path $packet 'matrix.json') | ConvertFrom-Json).candidate
$evidence = Join-Path $workspace ('review/attempt-replay-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $evidence | Out-Null
& (Join-Path $packet 'run-replay.ps1') $workspace $evidence $head
if ($LASTEXITCODE) { throw 'CLI evidence checks failed' }
Get-Content -Raw (Join-Path $evidence 'register-replay.json')
```

The [single-episode checker](check-metrics.py) runs the 19 fixed scenario, policy and seed combinations from [accepted Increment 5](accepted-main-matrix.json). It verifies event semantics, trace order, independently regenerated CSV and Parquet, and raw-derived counts. Each episode is read twice, with the recursive [store fingerprint](store-inventory.py) checked before and after the read series. The [action trace extractor](collect-action-trace.py) checks the manifest digests against those verified outputs and extracts the repeated-reading planner and original smoke cases. [Action traces and derived summaries](action-trace.json) · [Matrix](matrix.md) · [Command ledger](commands.json)

The approved PR #8 matrix at `9f58a43` has file SHA-256 `d93cd5cf5912ff16a6d8cd95bf782b4fe68c383f76be82165ab8c3620ac39c3a`. Across all 19 cases the following projection compares six replay fields with the approved digest. The full register reports include fresh invocation IDs, so the projection and action counts provide the cross-invocation comparison. From the packet’s CLI directory, run this with the verified environment.

```powershell
@'
import hashlib, json, sys
from pathlib import Path
matrix = json.loads(Path(sys.argv[1]).read_bytes())
keys = ("raw_semantic_hash", "summary_semantic_hash", "source_sequence_sha256", "trace_sha256", "regenerated_sha256", "metrics_sha256")
semantic = {case: {k: row[k] for k in keys} for case, row in matrix["runs"].items()}
assert len(semantic) == 19
digest = hashlib.sha256(json.dumps(semantic, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
assert digest == "9cc6fc7be339f6bc6e944f01d060ca99d2680f17d5eeabf2e972a5689f9f70fb"
print(digest)
'@ | & $uv run --project $checkout --frozen --no-sync python -B - (Join-Path $evidence 'matrix.json')
if ($LASTEXITCODE) { throw 'Opening Increment 6 compatibility failed' }
```

The [registered-set checker](check-register.py) writes eight named attempts with fresh invocation IDs and binds their canonical digest before creating synthetic outcomes. It uses public CLI processes for all report reads and successful episodes. For fault fixtures it interrupts an in-process audit worker before its first candidate, retains another partial worker output in staging, and calls the existing timeout-retention routine on a newly owned invocation. The timeout fixture exercises retention and classification directly. A separately completed invocation with a mismatched seed checks the invalid binding. Existing diagnostic records are preserved.

The initial report represents each planned attempt as incomplete. The final register contains three verified completions, one retained failure, one retained timeout, two incomplete attempts and one invalid binding. The checker verifies the status and metric visibility for each row, reconstructs observed totals by action ID from raw JSONL, checks both denominators, and compares a second invocation byte-for-byte. It tests a retry with an occupied invocation ID, duplicate labels, duplicate invocation IDs, an obsolete pin and equivalent JSON serialization. The mixed report and refusal checks retain the same register, staging tree and controlled-store fingerprints. IDs and timestamps vary across independent reproductions.

[Register](attempt-register.json) · [Initial accounting](initial-register-report.json) · [Mixed accounting](mixed-register-report.json) · [Replay evidence](register-replay.json) · [Registered command ledger](register-commands.json)

## Reproduce from the merged README

Run the two evaluator blocks in the [README at df33295](https://github.com/mthiessmeier/pacd-simulation/blob/df33295469094a5ed9aa26fcc4b1fa1d019d3e5c/README.md#reconstruct-inside-the-bounded-workspace) in one PowerShell session. The post-merge run used those blocks verbatim. Its clean checkout and run manifest both recorded the accepted work sample at `d5a2969`. [Post-merge walkthrough receipt](post-merge-readme-walkthrough.json)

## Repeat the original acceptance checks

The [walkthrough checker](check-readme.py) fetches the private repository’s README blob at the merge commit with the authenticated workspace GitHub CLI. In documented mode it executes the original fenced setup and diagnostic blocks at the README’s implementation pin `5eb554c`. In accepted mode it checks the revision substitution against the packaged script and runs the walkthrough at `d5a2969`. Each fresh clone records two planned attempts, completes one and leaves one unstarted. Both modes independently read back the doctor, event sequence, episode metrics and registered report.

```powershell
$checkout = (Resolve-Path '.').Path
foreach ($mode in @('accepted', 'documented')) {
    & $uv run --frozen --no-sync python -B (Join-Path $packet 'check-readme.py') $checkout $workspace $evidence $head $mode
    if ($LASTEXITCODE) { throw "Evaluator walkthrough failed for $mode" }
}
```

[Original implementation-pin walkthrough receipt](readme-smoke.json) · [Accepted-main walkthrough receipt](accepted-main-smoke.json)

