"""Extract two short diagnostic traces from previously verified, digest-bound main records."""
import csv
import hashlib
import io
import json
import sys
from pathlib import Path
from runpy import run_path

repo, workspace, evidence = (Path(s).resolve(strict=True) for s in sys.argv[1:4])
head = sys.argv[4]
packet = Path(__file__).resolve().parent
merge = run_path(str(packet/"main-identity.py"))["validate_main"](repo,head)
assert repo.parent == workspace/"repo" and evidence.is_relative_to(workspace/"review")
def sha(b):
    return hashlib.sha256(b).hexdigest()
def read(p):
    return json.loads(p.read_bytes())
def unique(rows, key):
    found = [r for r in rows if r["event_type"] == key]
    assert len(found) == 1
    return found[0]
matrix = read(evidence/"matrix.json")
assert matrix["candidate"] == head and matrix["all_accepted_hashes_matched"]
calls = {c["name"]: c for c in read(evidence/"commands.json")}
def verified_output(name):
    b = (evidence/"logs"/(name+".out")).read_bytes()
    assert calls[name]["commit"] == head and calls[name]["exit"] == 0 and calls[name]["stdout_sha256"] == sha(b)
    return json.loads(b)

examples = {}
for case in ("repeated-planner-first","smoke-legacy-first"):
    row = matrix["runs"][case]
    run = (workspace/"var/runs"/row["run_id"]).resolve(strict=True)
    assert run.parent == workspace/"var/runs" and run.name == row["run_id"]
    manifest_bytes = (run/"manifest.json").read_bytes()
    assert row["manifest_sha256"] == sha(manifest_bytes)
    manifest = json.loads(manifest_bytes)
    verified = verified_output(case+"-verify")
    trace = verified_output(case+"-defender")["defender_trace"]
    assert manifest["code_commit"] == head and manifest["dirty_state"] is False
    assert verified["valid"] and verified["execution_identity_assured"] and verified["errors"] == []
    assert verified["raw_semantic_hash"] == manifest["raw_semantic_hash"] == row["raw_semantic_hash"]
    assert verified["summary_semantic_hash"] == manifest["summary_semantic_hash"] == row["summary_semantic_hash"]
    assert trace["trace_sha256"] == row["trace_sha256"]
    raw = (run/"raw/events.jsonl").read_bytes()
    summary_bytes = (run/"derived/episode_summary.csv").read_bytes()
    assert sha(raw) == manifest["artifact_hashes"]["raw/events.jsonl"]
    assert sha(summary_bytes) == manifest["artifact_hashes"]["derived/episode_summary.csv"] == row["regenerated_sha256"]["episode_summary.csv"]
    summary, = csv.DictReader(io.StringIO(summary_bytes.decode("utf-8")))
    assert all(int(summary[k]) == v for k,v in row["metrics"]["counts"].items())
    events = [json.loads(line) for line in raw.splitlines()]
    assert all(r["run_id"] == run.name and r["evidence_label"] == "NON_REPORTABLE_DIAGNOSTIC" for r in events)
    assert int(summary["event_count"]) == len(events)
    examples[case] = item = {"run_id":run.name,"seed":manifest["seed"],"config_hash":summary["config_hash"],
        "manifest_sha256":sha(manifest_bytes),"raw_jsonl_sha256":sha(raw),"summary_csv_sha256":sha(summary_bytes),
        "summary":{k:int(v) if k.endswith("_count") else v for k,v in summary.items()},
        "raw_semantic_hash":row["raw_semantic_hash"],"summary_semantic_hash":row["summary_semantic_hash"],
        "actions":[]}
    for candidate in (r for r in events if r["event_type"] == "candidate_action"):
        action = candidate["action_id"]
        related = [r for r in events if r["action_id"] == action]
        cp = json.loads(candidate["payload_json"])
        sr = unique(related,"safety_decision")
        vr = unique(related,"verification")
        sp, vp = json.loads(sr["payload_json"]), json.loads(vr["payload_json"])
        assert sp["action_digest"] == cp["action_digest"] and sp["target_id"] == candidate["entity_id"]
        executed = [r for r in related if r["event_type"]=="simulated_execution"]
        if executed:
            er, = executed
            ep = json.loads(er["payload_json"])
            assert sp["action_digest"] == ep["authorized_action_digest"]
            assert sp["state_digest"] == ep["state_before_digest"] == ep["authorized_state_digest"]
            assert ep["network_enabled"] is False and sr["disposition"]=="APPROVE"
            assert vp["expected_effect_observed"] and vp["state_hashes_valid"]
            assert ep["execution_id"] == vp["execution_id"] and vp["verification_id"]
            pre, post = ep["state_before_digest"], ep["state_after_digest"]
            assert pre != post
        else:
            assert sr["disposition"] in {"ESCALATE","PROHIBIT"} and vr["outcome"]=="not_executed"
            pre,post=sp["state_digest"],vp.get("state_after_digest")
            if "state_before_digest" in vp:
                assert pre == vp["state_before_digest"] == post
        item["actions"].append({"action_id":action, "tick":candidate["tick"],"proposer":cp["proposer"],
            "action_type":cp["action_type"],"subject":candidate["entity_id"],"requested_authority":cp["requested_authority"],
            "action_sha256":cp["action_digest"],"governor_disposition":sr["disposition"],"governor_reason":sp["reason"],
            "simulated_executions":len(executed),"verification":vr["outcome"],
            "pre_state_sha256":pre,"post_state_sha256":post,
            "candidate_sequence":candidate["sequence"],"governor_sequence":sr["sequence"],"verification_sequence":vr["sequence"]})
    if case == "repeated-planner-first":
        observations=[r for r in events if r["event_type"]=="observation"]
        decisions=[r for r in events if r["event_type"]=="defender_decision"]
        assert len(observations)==len(decisions)==len(trace["decisions"])
        item["observations"]=[]
        for ob,de,tr in zip(observations,decisions,trace["decisions"],strict=True):
            op, dp=json.loads(ob["payload_json"]),json.loads(de["payload_json"])
            assert ob["tick"] == tr["observation"]["tick"] == de["tick"] and op["signal"] == tr["observation"]["signal"]
            assert de["outcome"] == tr["outcome"] and dp["previous_elevated_tick"] == tr["previous_elevated_tick"]
            item["observations"].append({"source_event":op["event_id"],"sensor":op["sensor_id"],"subject":ob["entity_id"],
                "tick":ob["tick"],"signal":op["signal"],"planner_outcome":de["outcome"],"previous_elevated_tick":dp["previous_elevated_tick"],
                "candidate_action_id":dp["candidate_action_id"],"observation_sequence":ob["sequence"],"decision_sequence":de["sequence"]})
        assert [(x["tick"],x["planner_outcome"]) for x in item["observations"]] == [
            (2,"below_threshold"),(3,"awaiting_corroboration"),(3,"awaiting_corroboration"),(4,"proposed"),(5,"already_referred")]
        assert len(item["actions"])==1 and item["actions"][0]["action_id"]==item["observations"][3]["candidate_action_id"]
        assert item["actions"][0]["pre_state_sha256"] == item["actions"][0]["post_state_sha256"]
    else:
        assert [a["governor_disposition"] for a in item["actions"]]==["APPROVE","ESCALATE","PROHIBIT"]
result = {"evidence_label":"NON_REPORTABLE_DIAGNOSTIC", **merge, "examples":examples}
(evidence/"action-trace.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print("Verified two raw-event traces, four action chains and their retained summaries.")
