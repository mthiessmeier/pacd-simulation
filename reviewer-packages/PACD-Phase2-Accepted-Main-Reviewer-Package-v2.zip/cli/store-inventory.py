"""Fingerprint authorized retained stores without opening files outside them."""
import hashlib
import json
import os
import stat
import sys
from pathlib import Path

workspace = Path(sys.argv[1]).resolve(strict=True)
entries = []
files = 0
for store in ("runs", "receipts", "invocations"):
    store_dir = workspace / "var" / store
    if store_dir.resolve(strict=True) != store_dir:
        raise ValueError("Unexpected indirect store directory")
    for parent, directories, filenames in os.walk(store_dir, followlinks=False):
        for name in directories + filenames:
            path = Path(parent) / name
            info = path.lstat()
            if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
                raise ValueError("Unexpected indirect store entry")
            encoded = None
            if path.is_file():
                with path.open("rb") as stream:
                    encoded = hashlib.file_digest(stream, "sha256").hexdigest()
                files += 1
            entries.append((path.relative_to(workspace / "var").as_posix(), info.st_size,
                            info.st_mtime_ns, info.st_mode, encoded))
entries.sort()
material = json.dumps(entries, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
print(json.dumps({"entries": len(entries), "files": files, "sha256": hashlib.sha256(material).hexdigest()}))
