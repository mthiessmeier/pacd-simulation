param([Parameter(Mandatory=$true)][string]$WorkspaceRoot,
      [Parameter(Mandatory=$true)][string]$EvidenceRoot,
      [Parameter(Mandatory=$true)][string]$ExpectedHead)
$ErrorActionPreference = 'Stop'
$repo = (Resolve-Path -LiteralPath '.').Path
$workspace = (Resolve-Path -LiteralPath $WorkspaceRoot).Path
$evidence = (Resolve-Path -LiteralPath $EvidenceRoot).Path
$uv = Join-Path $workspace 'var/cache/tools/uv/0.12.5/uv.exe'
$env:PATH = (Split-Path -Parent $uv) + ';' + $env:PATH
$env:UV_CACHE_DIR = Join-Path $workspace 'var/cache/uv-project'
$env:UV_PYTHON_DOWNLOADS = 'never'
$env:UV_OFFLINE = 'true'
$env:TEMP = Join-Path $workspace 'var/tmp'
$env:TMP = $env:TEMP
$env:PYTHONUTF8 = '1'
& $uv run --frozen --no-sync python -B (Join-Path $PSScriptRoot 'check-register.py') $repo $workspace $evidence $ExpectedHead
if ($LASTEXITCODE) { throw 'Registered-attempt CLI checks failed' }
& $uv run --frozen --no-sync python -B (Join-Path $PSScriptRoot 'check-metrics.py') $repo $workspace $evidence $ExpectedHead
if ($LASTEXITCODE) { throw 'Increment 6 diagnostic and metric checks failed' }
& $uv run --frozen --no-sync python -B (Join-Path $PSScriptRoot 'collect-action-trace.py') $repo $workspace $evidence $ExpectedHead
if ($LASTEXITCODE) { throw 'Digest-bound action-trace extraction failed' }
