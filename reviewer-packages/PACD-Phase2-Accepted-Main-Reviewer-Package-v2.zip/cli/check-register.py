"""Exercise the registered-attempt CLI in a fresh, prespecified mixed-outcome set."""
import hashlib
import json
import subprocess
import sys
import uuid
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path
from unittest.mock import patch

from pacd_sim.audit.writer import AuditWriter
from pacd_sim.harness import run as harness

repo, workspace, evidence = (Path(arg).resolve(strict=True) for arg in sys.argv[1:4])
head = sys.argv[4]
packet = Path(__file__).resolve().parent
from runpy import run_path
merge = run_path(str(packet/"main-identity.py"))["validate_main"](repo,head)
assert __debug__ and repo.parent == workspace/"repo" and evidence.is_relative_to(workspace/"review")
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip() == head
assert not subprocess.check_output(["git","status","--porcelain"],cwd=repo)
cli = repo/".venv/Scripts/pacd-sim.exe"
logs = evidence/"register-logs"
logs.mkdir()
calls = []
scenes = repo/"configs/scenarios"
controls = repo/"configs/defenders"
records = workspace/"var/runs"
names = ("original","repeated","zero","failed","timeout","partial","missing","mismatched")
attempts = [{"attempt_id":name,"invocation_id":uuid.uuid4().hex,"seed":424242} for name in names]
by_name = {entry["attempt_id"]:entry for entry in attempts}
reg = {"format":"pacd-attempt-register-v1","attempts":attempts}
seed = 424242
assert len({a["invocation_id"] for a in attempts}) == len(names)
work = workspace/"var/tmp"/("attempt-register-replay-"+uuid.uuid4().hex)
work.mkdir()
registry = work/"register.json"
def save(path, data):
    path.write_text(json.dumps(data,indent=2,sort_keys=True,allow_nan=False)+"\n",encoding="utf-8")
def read(path):
    return json.loads(path.read_bytes())
def sha(data):
    return hashlib.sha256(data).hexdigest()
def canonical(data):
    return json.dumps(data,ensure_ascii=False,allow_nan=False,sort_keys=True,separators=(",",":")).encode()
def inventory():
    return json.loads(subprocess.check_output([sys.executable,"-B",str(packet/"store-inventory.py"),str(workspace)],cwd=repo))
def cli_call(label,args,ok=True):
    start = datetime.now(UTC).isoformat()
    finished = subprocess.run([str(cli),*map(str,args)],cwd=repo,capture_output=True)
    streams = {"out":finished.stdout,"err":finished.stderr}
    for ext, data in streams.items():
        (logs/(label+"."+ext)).write_bytes(data)
    calls.append({"name":label,"arguments":[str(a).replace(str(workspace),"<workspace>") for a in args],
                  "start_utc":start,"end_utc":datetime.now(UTC).isoformat(),"exit":finished.returncode,
                  "stdout_sha256":sha(finished.stdout),"stderr_sha256":sha(finished.stderr)})
    save(evidence/"register-commands.json",calls)
    assert (finished.returncode == 0) == ok, (label,finished.returncode,(finished.stderr or finished.stdout)[-1200:])
    return json.loads(finished.stdout or finished.stderr)

def produce(name,scene,defender,actual_seed):
    invocation = by_name[name]["invocation_id"]
    result = cli_call(name+"-diagnostic",["diagnostic","--scenario",scenes/("diagnostic_"+scene+".yaml"),
                "--baseline",controls/(defender+".yaml"),"--seed",actual_seed,"--invocation-id",invocation,"--workspace-root",workspace])
    directory = Path(result["run_dir"]).resolve(strict=True)
    assert directory.parent == records and result["invocation_id"] == invocation and result["run_id"] == directory.name
    assert result["seed"] == actual_seed and read(directory/"manifest.json")["code_commit"] == head
    manifest_check = cli_call(name+"-verify",["verify",directory,"--workspace-root",workspace,"--show-event-sequence"])
    assert manifest_check["valid"] and manifest_check["execution_identity_assured"] and not manifest_check["reportable"]
    return directory

def inventory_registered_files():
    # The shared-store inventory covers final runs, receipts and ownership records.
    # Also cover the one unfinished staging tree we deliberately retain.
    staging = []
    for directory in (workspace/"var/tmp").glob("*-"+by_name["partial"]["invocation_id"]+".staging"):
        assert directory.is_dir() and not directory.is_symlink()
        for item in [directory,*sorted(directory.rglob("*"))]:
            info = item.lstat()
            assert not item.is_symlink() and not getattr(info,"st_file_attributes",0) & 1024
            staging.append((item.relative_to(directory).as_posix(), info.st_size, info.st_mode, info.st_mtime_ns,
                            sha(item.read_bytes()) if item.is_file() else None))
    return {"controlled_stores":inventory(),"register":(sha(registry.read_bytes()),registry.stat().st_mtime_ns),
            "partial_staging":{"entries":len(staging),"sha256":sha(canonical(staging))}}

def interrupts():
    # Use the real in-process audit worker with exclusive pre-allocated identifiers.
    # Inject one error at the candidate record; the actual parent retains FAILED.
    real_allocate = harness._create_invocation_ownership
    def interrupted(name,leave_staged):
        original = AuditWriter.emit
        def stop(writer,event,*args,**kwargs):
            if event == "candidate_action":
                raise RuntimeError("Registered-attempt replay fixture interrupted the synthetic episode")
            return original(writer,event,*args,**kwargs)
        ownership = real_allocate(records,workspace,seed,invocation_id=by_name[name]["invocation_id"])
        with patch.object(harness,"_create_invocation_ownership",return_value=ownership),patch.object(AuditWriter,"emit",stop):
            # Model an interruption between the worker's audit flush and parent finalization.
            if leave_staged:
                with patch.object(harness,"_retain_parent_failure",return_value=None):
                    run_until_interrupt()
            else:
                run_until_interrupt()
        target = ownership.staging_dir if leave_staged else ownership.final_run_dir
        assert target.is_dir() and (target/"raw/events.jsonl").is_file()
        assert bool((target/"status.json").is_file()) != leave_staged
        if not leave_staged:
            assert read(target/"status.json")["completion_status"] == "FAILED"
        return {"run_id":ownership.run_id,"status_sha256":None if leave_staged else sha((target/"status.json").read_bytes()),
                "raw_rows":len((target/"raw/events.jsonl").read_bytes().splitlines()),"raw_sha256":sha((target/"raw/events.jsonl").read_bytes())}
    def run_until_interrupt():
        try:
            harness._run_diagnostic_in_process(scenes/"diagnostic_identity_smoke.yaml",repo/"configs/policies/diagnostic_safety.yaml",
                repo/"configs/seeds/diagnostic_seeds.json",records,seed=seed,workspace_root=workspace,repo_root=repo,
                baseline_path=controls/"diagnostic_baseline.yaml",metric_path=repo/"configs/metrics/diagnostic_metrics.yaml")
        except RuntimeError as exc:
            assert "Registered-attempt replay fixture interrupted" in str(exc)
        else:
            raise AssertionError("Expected fixture interruption")
    failed = interrupted("failed",False)
    partial = interrupted("partial",True)
    ownership = real_allocate(records,workspace,seed,invocation_id=by_name["timeout"]["invocation_id"])
    harness._retain_timeout_evidence(workspace,ownership)
    status = ownership.final_run_dir/"status.json"
    assert read(status)["error_type"] == "DiagnosticTimeoutError"
    return {"failed":failed,"partial":partial,"timeout":{"run_id":ownership.run_id,"status_sha256":sha(status.read_bytes())}}

def oracle(directory):
    rows = [json.loads(line) for line in (directory/"raw/events.jsonl").read_bytes().splitlines()]
    actions = {r["action_id"] for r in rows if r["event_type"] == "candidate_action"}
    decisions = {r["action_id"]:r["disposition"] for r in rows if r["event_type"]=="safety_decision"}
    assert decisions.keys() == actions
    observed = Counter(decisions.values())
    executions = [r["action_id"] for r in rows if r["event_type"] == "simulated_execution"]
    return {"candidate_action_count":len(actions),"approved_action_count":observed["APPROVE"],
            "escalated_action_count":observed["ESCALATE"],"prohibited_action_count":observed["PROHIBIT"],
            "simulated_execution_count":len(executions),
            "verified_execution_count":sum(r["event_type"]=="verification" and r["outcome"]=="verified" for r in rows),
            "prohibited_execution_count":sum(decisions[a]=="PROHIBIT" for a in executions)}

def check_register(label,file,pin,ok=True):
    result = cli_call(label,["metrics","--register",file,"--register-sha256",pin,"--workspace-root",workspace],ok)
    if ok:
        assert result["format"] == "pacd-registered-metrics-v1"
        assert result["report_sha256"] == sha(canonical({k:v for k,v in result.items() if k!="report_sha256"}))
        assert result["evidence_label"] == "NON_REPORTABLE_DIAGNOSTIC" and result["reportable"] is False
        assert result["register_sha256"] == pin
        assert [row["attempt_id"] for row in result["attempts"]] == list(names)
        for row, planned in zip(result["attempts"],attempts,strict=True):
            assert all(row[k] == value for k,value in planned.items())
    else:
        assert "attempts" not in result and "observed_counts" not in result and "report_sha256" not in result
    return result

def ratio(data,numerator,denominator):
    assert data["numerator"] == numerator and data["denominator"] == denominator
    assert data["value"] == (numerator/denominator if denominator else None) and data["unit"]

save(registry,reg)
save(evidence/"attempt-register.json",reg)
register_digest = sha(canonical(reg))
start_inventory = inventory_registered_files()
initial = check_register("initial-register",registry,register_digest)
assert initial["status_counts"]["INCOMPLETE"] == len(names) and sum(initial["status_counts"].values()) == len(names)
assert all(row["status"] == "INCOMPLETE" and row["metrics"] is None and row["metrics_sha256"] is None for row in initial["attempts"])
assert initial["observed_counts"] is None and all(row["run_id"] is None for row in initial["attempts"])
ratio(initial["completion_fraction"],0,len(names))
ratio(initial["observed_escalation_fraction"],0,0)
assert inventory_registered_files() == start_inventory

directories = {
    "original":produce("original","identity_smoke","diagnostic_baseline",seed),
    "repeated":produce("repeated","repeated_readings","static_review",seed),
    "zero":produce("zero","identity_smoke","pacd_corroborated_review",seed),
    "mismatched":produce("mismatched","repeated_readings","pacd_corroborated_review",424243),
}
faults = interrupts()
before = inventory_registered_files()
assert before["partial_staging"]["entries"] > 1
retry = cli_call("occupied-invocation",["diagnostic","--invocation-id",by_name["original"]["invocation_id"],
                  "--scenario",scenes/"diagnostic_identity_smoke.yaml","--baseline",controls/"diagnostic_baseline.yaml",
                  "--workspace-root",workspace,"--seed",seed],False)
assert retry.get("valid") is False and "run_dir" not in retry
assert inventory_registered_files() == before

final = check_register("mixed-register-first",registry,register_digest)
again = check_register("mixed-register-repeat",registry,register_digest)
assert again == final and calls[-1]["stdout_sha256"] == calls[-2]["stdout_sha256"]
expected_status = ("COMPLETED","COMPLETED","COMPLETED","FAILED","TIMED_OUT","INCOMPLETE","INCOMPLETE","INVALID")
assert tuple(row["status"] for row in final["attempts"]) == expected_status
assert final["attempts"][4]["reason"] == "DiagnosticTimeoutError" and final["attempts"][5]["reason"] == "staging_only"
assert final["attempts"][6]["reason"] == "no_registered_invocation_observed"
assert final["status_counts"] == dict(Counter(expected_status))
totals = Counter()
episodes = {}
for row in final["attempts"]:
    name = row["attempt_id"]
    if row["status"] == "COMPLETED":
        count = oracle(directories[name])
        assert row["run_id"] == directories[name].name and row["metrics"]["counts"] == count
        assert row["metrics_sha256"] == sha(canonical(row["metrics"]))
        report = cli_call(name+"-episode",["metrics",directories[name],"--workspace-root",workspace])
        assert report["run_id"] == row["run_id"] and report["metrics"] == row["metrics"] and report["metrics_sha256"] == row["metrics_sha256"]
        ratio(row["metrics"]["escalation_fraction"],count["escalated_action_count"],count["candidate_action_count"])
        totals.update(count)
        episodes[name] = {"run_id":row["run_id"],"metrics_sha256":row["metrics_sha256"],"raw_sha256":sha((directories[name]/"raw/events.jsonl").read_bytes()),"counts":count}
    else:
        assert row["metrics"] is None and row["metrics_sha256"] is None and row["reason"]
    if name in faults:
        assert row["run_id"] == faults[name]["run_id"]
assert final["observed_counts"] == dict(totals)
assert (totals["escalated_action_count"],totals["candidate_action_count"],totals["prohibited_execution_count"]) == (5,7,0)
ratio(final["completion_fraction"],3,8)
ratio(final["observed_escalation_fraction"],5,7)
reformatted = work/"equivalent.json"
reformatted.write_bytes(json.dumps({"attempts":attempts,"format":reg["format"]},separators=(",",":")).encode("utf-8"))
assert reformatted.read_bytes() != registry.read_bytes()
equivalent = check_register("canonical-equivalent",reformatted,register_digest)
assert equivalent == final
for field in ("attempt_id","invocation_id"):
    duplicate = [dict(entry) for entry in attempts]
    duplicate[1][field] = duplicate[0][field]
    bad = {"format":reg["format"],"attempts":duplicate}
    path = work/("duplicate-"+field+".json")
    save(path,bad)
    check_register("duplicate-"+field,path,sha(canonical(bad)),False)
changed = {"format":reg["format"],"attempts":attempts[:-1]}
changed_path = work/"changed.json"
save(changed_path,changed)
assert sha(canonical(changed)) != register_digest
check_register("changed-plan-old-pin",changed_path,register_digest,False)
after = inventory_registered_files()
assert before == after
assert not subprocess.check_output(["git","status","--porcelain"],cwd=repo)
for call in calls:
    for ext,key in [("out","stdout_sha256"),("err","stderr_sha256")]:
        assert sha((logs/(call["name"]+"."+ext)).read_bytes()) == call[key]
save(evidence/"initial-register-report.json",initial)
save(evidence/"mixed-register-report.json",final)
save(evidence/"register-replay.json",{
    "candidate":head,**merge,"evidence_label":"NON_REPORTABLE_DIAGNOSTIC","register_sha256":register_digest,
    "report_sha256":final["report_sha256"],"status_counts":final["status_counts"],"completion_fraction":final["completion_fraction"],
    "observed_escalation_fraction":final["observed_escalation_fraction"],"observed_counts":dict(totals),"before":before,"after":after,
    "initial_all_unobserved":True,"changed_pin_rejected":True,"duplicate_ids_rejected":True,"occupied_invocation_refused_without_changes":True,
    "equivalent_json_matched":True,"identical_repeat_stdout_sha256":sha((logs/"mixed-register-first.out").read_bytes()),
    "fault_fixtures":faults, "completed_run_oracle":episodes,"command_count":len(calls),"expected_refusal_count":4,
})
print(f"{len(calls)} registered-set CLI commands returned expected exits. Completion 3/8; observed escalations 5/7.")

