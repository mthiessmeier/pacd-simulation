$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$true
$WorkspaceRoot = Join-Path $env:USERPROFILE 'PACD-Workspaces\PACD-Simulation'
$Revision = 'd5a29699e14409bfd54d30c51117c81077639ee6'
$RepoParent = Join-Path $WorkspaceRoot 'repo'
$RepoRoot = Join-Path $RepoParent ('evaluator-i6-' + [guid]::NewGuid().ToString('N').Substring(0,10))
$uv = Join-Path $WorkspaceRoot 'var\cache\tools\uv\0.12.5\uv.exe'
$UvCache = Join-Path $WorkspaceRoot 'var\cache\uv-project'
$PreCommitCache = Join-Path $WorkspaceRoot 'var\cache\pre-commit'
$TaskTemp = Join-Path $WorkspaceRoot ('var\tmp\evaluator-' + [guid]::NewGuid().ToString('N'))
$MatplotlibCache = Join-Path $WorkspaceRoot 'var\cache\matplotlib'

foreach ($DirectoryToCreate in @($RepoParent, $UvCache, $PreCommitCache, $TaskTemp, $MatplotlibCache)) {
    if (-not (Test-Path -LiteralPath $DirectoryToCreate)) {
        New-Item -ItemType Directory -Path $DirectoryToCreate | Out-Null
    }
}

$env:UV_CACHE_DIR = $UvCache
$env:UV_PYTHON_DOWNLOADS = 'never'
$env:PATH = (Split-Path -Parent $uv) + ';' + $env:PATH
$env:PRE_COMMIT_HOME = $PreCommitCache
$env:TEMP = $TaskTemp
$env:TMP = $TaskTemp
$env:MPLCONFIGDIR = $MatplotlibCache

if (Test-Path -LiteralPath $RepoRoot) { throw 'Choose an unused checkout path' }
git clone --no-checkout https://github.com/mthiessmeier/pacd-simulation.git $RepoRoot
if ($LASTEXITCODE) { throw 'Private repository clone failed' }
Set-Location -LiteralPath $RepoRoot
git switch --create reproduce-increment6 $Revision
if ($LASTEXITCODE -or (git rev-parse HEAD) -ne $Revision) { throw 'Reproduction checkout failed' }
& $uv sync --frozen --offline --python 3.13.15
if ($LASTEXITCODE) { throw 'Frozen environment setup failed' }
& $uv run --frozen --no-sync pacd-sim doctor --workspace-root $WorkspaceRoot
if ($LASTEXITCODE) { throw 'Environment verification failed' }

$RunRoot = Join-Path $WorkspaceRoot 'var\runs'
$Invocation = [guid]::NewGuid().ToString('N')
$RegisterPath = Join-Path $TaskTemp 'attempt-register.json'
$Register = @{
    format = 'pacd-attempt-register-v1'
    attempts = @(
        @{attempt_id='repeated-reading'; invocation_id=$Invocation; seed=424242}
        @{attempt_id='reserved-control'; invocation_id=[guid]::NewGuid().ToString('N'); seed=424242}
    )
}
[IO.File]::WriteAllText($RegisterPath, ($Register | ConvertTo-Json -Depth 4), [Text.UTF8Encoding]::new($false))
$Before = & $uv run --frozen --no-sync pacd-sim metrics --register $RegisterPath --workspace-root $WorkspaceRoot | ConvertFrom-Json
if ($LASTEXITCODE -or $Before.status_counts.INCOMPLETE -ne 2) { throw 'Register preflight failed' }
$RegisterPin = $Before.register_sha256
$Diagnostic = & $uv run --frozen --no-sync pacd-sim diagnostic --workspace-root $WorkspaceRoot --output-root $RunRoot --scenario configs/scenarios/diagnostic_repeated_readings.yaml --baseline configs/defenders/pacd_corroborated_review.yaml --seed 424242 --invocation-id $Invocation | ConvertFrom-Json
if ($LASTEXITCODE) { throw 'Diagnostic failed' }
$Verified = & $uv run --frozen --no-sync pacd-sim verify $Diagnostic.run_dir --workspace-root $WorkspaceRoot --show-event-sequence | ConvertFrom-Json
if ($LASTEXITCODE -or !$Verified.execution_identity_assured) { throw 'Run verification failed' }
$Trace = & $uv run --frozen --no-sync pacd-sim defender-trace $Diagnostic.run_dir --workspace-root $WorkspaceRoot | ConvertFrom-Json
if ($LASTEXITCODE) { throw 'Planner replay failed' }
$Trace.defender_trace.decisions | Select-Object outcome, previous_elevated_tick
$Report = & $uv run --frozen --no-sync pacd-sim metrics $Diagnostic.run_dir --workspace-root $WorkspaceRoot | ConvertFrom-Json
if ($LASTEXITCODE -or !$Report.valid) { throw 'Metric verification failed' }
$Report.metrics | ConvertTo-Json -Depth 4
$SetReport = & $uv run --frozen --no-sync pacd-sim metrics --register $RegisterPath --register-sha256 $RegisterPin --workspace-root $WorkspaceRoot | ConvertFrom-Json
if ($LASTEXITCODE -or $SetReport.status_counts.COMPLETED -ne 1 -or $SetReport.status_counts.INCOMPLETE -ne 1) { throw 'Registered attempt accounting failed' }
$SetReport.attempts | Select-Object attempt_id, status, reason
$SetReport.completion_fraction
$SetReport.observed_escalation_fraction
