# Verified episode disposition metrics

All 19 runs on accepted main matched the prior verified results on raw and summary semantics, event sequence, defender trace and regenerated outputs. The metric values below were independently computed from each retained audit row.

| Source | Seed | Invocation | Escalations | Candidates | Fraction | Simulated executions | Metric SHA-256 prefix |
| --- | ---: | --- | ---: | ---: | --- | ---: | --- |
| smoke / planner | 424242 | first | 0 | 0 | undefined | 0 | `faa658cb6930` |
| smoke / planner | 424242 | repeat | 0 | 0 | undefined | 0 | `faa658cb6930` |
| smoke / planner | 424243 | alternate | 0 | 0 | undefined | 0 | `54343ad00d14` |
| smoke / static | 424242 | first | 1 | 1 | 1.0 | 0 | `e6082fe0cf0c` |
| smoke / static | 424243 | alternate | 1 | 1 | 1.0 | 0 | `499a1cbc4f97` |
| smoke / legacy | 424242 | first | 1 | 3 | 0.3333333333333333 | 1 | `ae4c43cfe558` |
| smoke / legacy | 424243 | alternate | 1 | 3 | 0.3333333333333333 | 1 | `eaf5092d8ba0` |
| maintenance / planner | 424242 | first | 0 | 0 | undefined | 0 | `001e66277ab6` |
| maintenance / planner | 424242 | repeat | 0 | 0 | undefined | 0 | `001e66277ab6` |
| maintenance / planner | 424243 | alternate | 0 | 0 | undefined | 0 | `f46117e09479` |
| maintenance / static | 424242 | first | 1 | 1 | 1.0 | 0 | `d9bbfac9dfe8` |
| maintenance / static | 424243 | alternate | 1 | 1 | 1.0 | 0 | `bce6e3d0ee8e` |
| maintenance / legacy | 424242 | first | 1 | 3 | 0.3333333333333333 | 1 | `89e2b7b1466e` |
| maintenance / legacy | 424243 | alternate | 1 | 3 | 0.3333333333333333 | 1 | `d77f52021235` |
| repeated / planner | 424242 | first | 1 | 1 | 1.0 | 0 | `3448d62ba13e` |
| repeated / planner | 424242 | repeat | 1 | 1 | 1.0 | 0 | `3448d62ba13e` |
| repeated / planner | 424243 | alternate | 1 | 1 | 1.0 | 0 | `ae03cb59e24e` |
| repeated / static | 424242 | first | 4 | 4 | 1.0 | 0 | `200d7d0f81cd` |
| repeated / static | 424243 | alternate | 4 | 4 | 1.0 | 0 | `d5e18d3186db` |

All 38 metric invocations verified the receipt and matched the independent counts, ratio and public digest. Two reads of each retained run returned identical bytes. The retained data and metadata fingerprints before and after those reads also matched. These are non-reportable synthetic episode descriptors. The [matrix](matrix.json) records complete metrics, semantic hashes and run IDs. The [command ledger](commands.json) records all 114 exits and 228 output digests.
