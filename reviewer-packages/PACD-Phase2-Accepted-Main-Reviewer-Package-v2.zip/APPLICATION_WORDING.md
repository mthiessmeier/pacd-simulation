# Residency application wording

## CV bullets

- Authored the Polymorphic Agentic Cyberdefense monograph and directed a companion simulator that traces defensive proposals through authorization and verifies their effects on synthetic sessions.
- Set the scope and review criteria for a Codex-assisted work sample that lets an evaluator register attempts, replay a defender’s decisions and trace reported counts back to individual events.

## Technical work description

I authored the Polymorphic Agentic Cyberdefense monograph and direct its companion simulator project. I wanted a reviewer to be able to reconstruct what a defender knew when it proposed an action, who could authorize that action and what changed afterward.

In one synthetic scenario, two elevated sensor readings arrive for the same identity on the same tick. The planner waits. A reading on the next tick prompts a request for human review. The governor escalates the request. The audit shows that the simulated state was identical before and after the decision.

I also wanted failures to remain visible. In an eight-attempt diagnostic, three episodes completed. The other five stayed in the report with their status and no action counts. The completed episodes contained seven candidate actions, five of which escalated. A reviewer can inspect the event records behind those counts and replay the same register. I set the research direction and review boundaries. Codex assisted with implementation and testing.

[Accepted main commit](https://github.com/mthiessmeier/pacd-simulation/commit/d5a29699e14409bfd54d30c51117c81077639ee6) · [Trace and measured outcomes](README.md) · [Evidence and limitations](CLAIMS.md)
