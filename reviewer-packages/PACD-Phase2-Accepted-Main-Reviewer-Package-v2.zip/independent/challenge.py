"""Cross-check the public CLI's attempt accounting from independently read raw action IDs."""
import csv
import hashlib
import json
import subprocess
import sys
from collections import Counter
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch

repo = Path.cwd().resolve()
sys.path[:0] = [str(repo / "src"), str(repo / "tests"), str(repo / "tests/reproducibility")]
from conftest import _create_isolated_workspace, controlled_config_files
from pacd_sim import cli
from pacd_sim.audit.writer import AuditWriter
from pacd_sim.harness import run
from test_diagnostic_replay import _refresh_integrity_closure

SEED = 424242


def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo, text=True).strip()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def wire(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True, allow_nan=False).encode()


def inventory(ws):
    rows = []
    for item in sorted((ws.root / "var").rglob("*")):
        s = item.stat()
        rows.append([item.relative_to(ws.root).as_posix(), s.st_mode, s.st_ino, s.st_mtime_ns,
                     sha(item.read_bytes()) if item.is_file() else None])
    return sha(wire(rows))


def entry(number, label):
    return {"attempt_id": label, "invocation_id": format(number, "032x"), "seed": SEED}


def register(path, entries):
    data = {"format": "pacd-attempt-register-v1", "attempts": entries}
    path.write_bytes(wire(data))
    return sha(wire(data))


def avoid_execution(*args, **kwargs):
    raise AssertionError("A read-only metrics command initiated execution")


def invoke(ws, reg, pinned=None):
    args = ["metrics", "--register", str(reg), "--workspace-root", str(ws.root)]
    if pinned is not None:
        args += ["--register-sha256", pinned]
    readings = []
    before = inventory(ws)
    with ExitStack() as ctx:
        for name, method in [
            ("pacd_sim.cli._default_repo_root", lambda: ws.repo_root),
            ("pacd_sim.reproducibility.paths.default_workspace_root", lambda: ws.root),
            ("pacd_sim.cli._emit_json", lambda data, **kw: readings.append(data)),
            ("pacd_sim.cli.run_diagnostic", avoid_execution),
            ("pacd_sim.harness.run.SimulatedExecutionBroker.execute", avoid_execution),
        ]:
            ctx.enter_context(patch(name, method))
        result = cli.main(args)
    assert inventory(ws) == before, "Metrics read changed a retained directory or file"
    assert len(readings) == 1, readings
    return result, readings[0]


def produce(ws, spec, scene, defender, fault=None, *, after_worker=False):
    smoke, policy, seeds, _, metric = controlled_config_files(ws.config_root)
    scenario = smoke.with_name("diagnostic_" + scene + ".yaml")
    prior = set(ws.output_root.iterdir())
    allocate = run._create_invocation_ownership
    emit = AuditWriter.emit

    def reserve(output, workspace, seed, **kwargs):
        if kwargs.get("invocation_id") not in (None, spec["invocation_id"]):
            raise AssertionError("Harness used a conflicting registered identity")
        return allocate(output, workspace, seed, invocation_id=spec["invocation_id"])

    def produce_event(writer, event, *args, **kwargs):
        if fault is not None and not after_worker and event == "candidate_action":
            raise fault("Independent retained failure test")
        return emit(writer, event, *args, **kwargs)

    with patch("pacd_sim.harness.run.default_workspace_root", return_value=ws.root), \
         patch.object(run, "_create_invocation_ownership", reserve), \
         patch.object(AuditWriter, "emit", produce_event), ExitStack() as ctx:
        if after_worker:
            ctx.enter_context(patch.object(run, "_finalize_owned_result",
                                           side_effect=fault("Independent retained failure test")))
        try:
            result = run._run_diagnostic_in_process(
                scenario, policy, seeds, ws.output_root, seed=spec["seed"],
                baseline_path=ws.config_root / "defenders" / (defender + ".yaml"),
                metric_path=metric, workspace_root=ws.root, repo_root=ws.repo_root,
            )
        except (TimeoutError, RuntimeError) as error:
            assert type(error) is fault and str(error) == "Independent retained failure test"
            result = None
        else:
            assert fault is None
    retained, = set(ws.output_root.iterdir()) - prior
    assert retained.name.endswith("-" + spec["invocation_id"])
    status = json.loads((retained / "status.json").read_bytes())
    if fault is not None:
        assert status["completion_status"] == "FAILED" and status["error_type"] == fault.__name__
        assert not (ws.root / "var/receipts" / (spec["invocation_id"] + ".json")).exists()
    else:
        assert result.run_dir == retained and result.invocation_id == spec["invocation_id"]
        assert result.receipt_path.is_file()
    return retained, result


def oracle(run_dir):
    rows = [json.loads(row) for row in (run_dir / "raw/events.jsonl").read_bytes().splitlines()]
    ids = {r["action_id"] for r in rows if r["event_type"] == "candidate_action"}
    decisions = {r["action_id"]: r["disposition"] for r in rows if r["event_type"] == "safety_decision"}
    executed = {r["action_id"] for r in rows if r["event_type"] == "simulated_execution"}
    verified = {r["action_id"] for r in rows if r["event_type"]=="verification" and r["outcome"]=="verified"}
    rejected = {k for k,v in decisions.items() if v == "PROHIBIT"}
    assert ids == decisions.keys() and verified <= executed <= ids
    return {"candidate_action_count": len(ids), "approved_action_count": sum(v=="APPROVE" for v in decisions.values()),
            "escalated_action_count": sum(v=="ESCALATE" for v in decisions.values()), "prohibited_action_count": len(rejected),
            "simulated_execution_count":len(executed), "verified_execution_count":len(verified),
            "prohibited_execution_count":len(rejected & executed)}


def damage_summary(run_dir):
    path = run_dir / "derived/episode_summary.csv"
    with path.open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        fields = reader.fieldnames
        row, = reader
    original = row["escalated_action_count"]
    row["escalated_action_count"] = str(int(original) + 5)
    with path.open("w",encoding="utf-8",newline="") as handle:
        writer=csv.DictWriter(handle,fieldnames=fields,lineterminator="\n")
        writer.writeheader()
        writer.writerow(row)
    _refresh_integrity_closure(run_dir, ("derived/episode_summary.csv",))


def check_fraction(actual, numerator, denominator):
    assert (actual["numerator"],actual["denominator"]) == (numerator,denominator)
    assert actual["value"] == (numerator / denominator if denominator else None)
    assert actual["unit"]


def refused_registers(ws, reg, entries, pinned):
    observed = {}
    alternatives = {
        "reused_attempt_label": [*entries, {**entries[0],"invocation_id":"f"*32}],
        "reused_invocation": [*entries,{**entries[0],"attempt_id":"reused-retry"}],
        "boolean_seed": [{**entries[0], "seed": True}],
        "unrecognized_field": [{**entries[0],"score":0.5}],
    }
    for label, value in alternatives.items():
        path = reg.with_name(label + ".json")
        register(path, value)
        status, failed = invoke(ws, path)
        assert status != 0 and {"report_sha256","observed_counts","attempts"}.isdisjoint(failed)
        observed[label] = {"exit": status, "status": failed["status"]}
    mismatch = "f"*64 if pinned != "f"*64 else "e"*64
    status, failed = invoke(ws, reg, mismatch)
    assert status != 0 and {"report_sha256","observed_counts","attempts"}.isdisjoint(failed)
    observed["incorrect_pin"] = {"exit":status, "status":failed["status"]}
    path=reg.with_name("duplicate-key.json")
    path.write_bytes(reg.read_bytes().replace(b'"seed":424242',b'"seed":424242,"seed":424242',1))
    status, failed = invoke(ws, path)
    assert status != 0 and {"report_sha256","observed_counts","attempts"}.isdisjoint(failed)
    observed["duplicate_json_key"] = {"exit":status, "status":failed["status"]}
    return observed


def challenge(head, scratch):
    assert __debug__ and git("rev-parse","HEAD")==head and not git("status","--porcelain")
    ws = _create_isolated_workspace(scratch / "PACD-Workspaces" / "PACD-Simulation")
    slots = {s["attempt_id"]:s for s in [
        entry(1,"original"),entry(2,"failed"),entry(3,"static"),entry(4,"timed-out"),
        entry(5,"not-started"),entry(6,"in-progress"),entry(7,"bad-receipt"),entry(8,"retry"),entry(9,"no-actions"),
        entry(10,"late-failure")
    ]}
    reg = ws.root / "review-register.json"
    pinned = register(reg, list(slots.values()))
    initial_code, initial = invoke(ws, reg, pinned)
    good = {}
    bad = {}
    for label, scene, defender, fault in [
        ("original","identity_smoke","diagnostic_baseline",None),
        ("failed","repeated_readings","pacd_corroborated_review",RuntimeError),
        ("static","repeated_readings","static_review",None),
        ("timed-out","identity_smoke","diagnostic_baseline",run.DiagnosticTimeoutError),
        ("bad-receipt","repeated_readings","static_review",None),
        ("retry","repeated_readings","pacd_corroborated_review",None),
        ("no-actions","identity_smoke","pacd_corroborated_review",None),
    ]:
        pair = produce(ws,slots[label],scene,defender,fault)
        (bad if fault is not None or label == "bad-receipt" else good)[label] = pair
    slot = slots["in-progress"]
    partial = run._create_invocation_ownership(ws.output_root,ws.root,slot["seed"],invocation_id=slot["invocation_id"])
    (partial.staging_dir / "review.part").write_text("test interruption", encoding="utf-8")
    bad["late-failure"] = produce(ws, slots["late-failure"], "identity_smoke", "diagnostic_baseline",
                                    RuntimeError, after_worker=True)
    late_dir = bad["late-failure"][0]
    assert oracle(late_dir)["simulated_execution_count"] == 1
    assert json.loads((late_dir/"manifest.json").read_bytes())["completion_status"] == "FAILED"
    receipt = bad["bad-receipt"][1].receipt_path
    receipt.write_bytes(good["original"][1].receipt_path.read_bytes())
    code, mixed = invoke(ws,reg,pinned)
    assert (code,mixed) == invoke(ws,reg,pinned)
    return finish_review(head,ws,reg,slots,pinned,initial_code,initial,code,mixed,good,bad)

def finish_review(head,ws,reg,slots,pinned,initial_code,initial,code,mixed,good,bad):
    assert initial_code == code == 0
    assert initial["register_sha256"] == mixed["register_sha256"] == pinned
    assert [row["attempt_id"] for row in initial["attempts"]] == list(slots)
    assert all(row["status"] == "INCOMPLETE" and row["metrics"] is None for row in initial["attempts"])
    check_fraction(initial["completion_fraction"], 0, 10)
    check_fraction(initial["observed_escalation_fraction"], 0, 0)
    assert initial["observed_counts"] is None
    expected_status = {
        "original":"COMPLETED","failed":"FAILED","static":"COMPLETED","timed-out":"TIMED_OUT",
        "not-started":"INCOMPLETE","in-progress":"INCOMPLETE","bad-receipt":"INVALID",
        "retry":"COMPLETED","no-actions":"COMPLETED","late-failure":"FAILED"
    }
    assert list(expected_status) == list(slots)
    assert [row["attempt_id"] for row in mixed["attempts"]] == list(slots)
    assert mixed["evidence_label"] == "NON_REPORTABLE_DIAGNOSTIC" and mixed["reportable"] is False
    totals = Counter()
    for row in mixed["attempts"]:
        label = row["attempt_id"]
        assert all(row[k] == v for k,v in slots[label].items())
        assert row["status"] == expected_status[label], (label,row)
        if label in good:
            run_dir = good[label][0]
            counts = oracle(run_dir)
            assert row["run_id"] == run_dir.name and counts == row["metrics"]["counts"]
            assert sha(wire(row["metrics"])) == row["metrics_sha256"]
            check_fraction(row["metrics"]["escalation_fraction"],counts["escalated_action_count"],counts["candidate_action_count"])
            totals.update(counts)
        else:
            assert row["metrics"] is None and row["metrics_sha256"] is None
            if label in bad:
                assert row["run_id"] == bad[label][0].name
            if label == "not-started":
                assert row["run_id"] is None
    assert mixed["status_counts"] == Counter(expected_status.values())
    assert dict(totals) == mixed["observed_counts"]
    check_fraction(mixed["completion_fraction"], 4, 10)
    check_fraction(mixed["observed_escalation_fraction"], 6, 8)
    assert totals["simulated_execution_count"]==totals["verified_execution_count"]==1
    assert totals["prohibited_execution_count"]==0
    for report in [initial,mixed]:
        assert sha(wire({k:v for k,v in report.items() if k != "report_sha256"})) == report["report_sha256"]
    assert initial["report_sha256"] != mixed["report_sha256"]

    order_reg=reg.with_name("reversed.json")
    reversed_pin = register(order_reg, list(slots.values())[::-1])
    rc,reordered = invoke(ws,order_reg,reversed_pin)
    assert rc == 0 and reordered["attempts"] == mixed["attempts"][::-1]
    assert reordered["observed_counts"] == mixed["observed_counts"] and reordered["status_counts"] == mixed["status_counts"]
    assert reordered["register_sha256"] != pinned and reordered["report_sha256"] != mixed["report_sha256"]
    rejections=refused_registers(ws,reg,list(slots.values()),pinned)
    only_zero=reg.with_name("zero.json")
    zero_pin=register(only_zero,[slots["no-actions"]])
    zero_code,zero = invoke(ws,only_zero,zero_pin)
    assert zero_code==0 and set(zero["observed_counts"].values()) == {0}
    check_fraction(zero["observed_escalation_fraction"],0,0)
    check_fraction(zero["completion_fraction"],1,1)

    # Use dedicated, retained evidence in the scratch workspace for these negative tests.
    # A receipt-bound original must not become a failed observation merely because status changes.
    original = good["original"][0]
    (original/"status.json").write_bytes((bad["failed"][0]/"status.json").read_bytes())
    damage_summary(good["static"][0])
    wrongseed=reg.with_name("different-seed.json")
    wrongseed_pin=register(wrongseed,[{**slots["retry"],"seed":SEED+1}])
    seedcode,seedresult=invoke(ws,wrongseed,wrongseed_pin)
    assert seedcode==0 and seedresult["attempts"][0]["status"]=="INVALID" and seedresult["observed_counts"] is None
    ignored,damaged=invoke(ws,reg,pinned)
    assert ignored==0 and damaged["status_counts"]["INVALID"]==3
    rows={r["attempt_id"]:r for r in damaged["attempts"]}
    assert all(rows[k]["status"]=="INVALID" and rows[k]["metrics"] is None for k in ["original","static","bad-receipt"])
    check_fraction(damaged["completion_fraction"],2,10)
    check_fraction(damaged["observed_escalation_fraction"],1,1)

    # Even a retained late failed manifest cannot release observations or contradict its status.
    late=bad["late-failure"][0] / "manifest.json"
    altered=json.loads(late.read_bytes())
    altered["failure_type"]="UnrelatedError"
    late.write_bytes(wire(altered))
    rc,conflict=invoke(ws,reg,pinned)
    conflict_row=next(r for r in conflict["attempts"] if r["attempt_id"]=="late-failure")
    assert rc==0 and conflict_row["status"]=="INVALID" and conflict_row["metrics"] is None
    assert conflict["observed_counts"]==damaged["observed_counts"]
    # A retry may not reuse the registered ID of a retained receipt whose ownership marker is lost.
    used_id=slots["no-actions"]["invocation_id"]
    old_owner=ws.root / "var/invocations" / used_id
    old_owner.rename(old_owner.with_name(used_id+"-held"))
    rc,orphan=invoke(ws,reg,pinned)
    unowned=next(r for r in orphan["attempts"] if r["attempt_id"]=="no-actions")
    assert rc==0 and unowned["status"]=="INVALID" and unowned["metrics"] is None
    before=inventory(ws)
    rejection=[]
    with patch("pacd_sim.reproducibility.paths.default_workspace_root",return_value=ws.root), \
         patch("pacd_sim.harness.run.default_workspace_root",return_value=ws.root), \
         patch.object(cli,"_default_repo_root",return_value=ws.repo_root), \
         patch.object(cli,"_emit_json",lambda value,**kw: rejection.append(value)):
        rc=cli.main(["diagnostic","--workspace-root",str(ws.root),"--repo-root",str(ws.repo_root),
                     "--seed",str(SEED),"--invocation-id",used_id])
    assert rc!=0 and len(rejection)==1 and inventory(ws)==before, "Orphan receipt allowed ID reuse"
    assert not git("status","--porcelain") and git("rev-parse","HEAD")==head
    approved="9f58a43021eb1efe159a55b4540e0e872b963349"
    previous="9c9dfcec659870c41aa7cc95846d6760d9c31df7"
    assert git("branch","--show-current") == "main"
    assert git("rev-list","--parents","-1",head).split() == [head, previous, approved]
    assert git("rev-parse", head+"^{tree}") == git("rev-parse", approved+"^{tree}") == "b8f84815f15aee2473ea2150820497777eb541b6"
    implementation=git("rev-parse",approved+"^")
    assert implementation == "5eb554c21b008038ecc50d0f7433977bef64ba7a"
    assert git("diff","--name-only",implementation,head).splitlines()==["README.md"]
    guide = (repo/"README.md").read_text(encoding="utf-8")
    assert implementation in guide and "--register" in guide
    return {"reviewed_head":head,"implementation_head":implementation,"register_sha256":pinned,
            "initial_status_counts":initial["status_counts"],"initial_observed_counts":initial["observed_counts"],
            "status_counts":mixed["status_counts"],"completion_fraction":mixed["completion_fraction"],
            "observed_counts":dict(totals),"observed_escalation_fraction":mixed["observed_escalation_fraction"],
            "full_report_sha256":mixed["report_sha256"],"rows":mixed["attempts"],
            "late_failure_with_completed_raw_files_withheld":True,"swapped_receipt_withheld":True,
            "retained_timeout_type":run.DiagnosticTimeoutError.__name__,"same_condition_retry_distinct":True,
            "all_read_store_inventories_unchanged":True,"changed_seed_invalid":True,"verified_zero_distinct_from_no_observations":True,
            "rehashed_false_summary_invalid":True,"false_failure_for_receipted_completion_invalid":True,
            "status_manifest_conflict_invalid":True,"schema_and_pin_rejections":rejections,
            "orphan_receipt_prevents_registered_id_reuse_without_writes":True,
            "order_reversed_rows_preserved":True,"exact_mixed_replay":True,"evidence_label":"NON_REPORTABLE_DIAGNOSTIC"}


if __name__=="__main__":
    print(json.dumps(challenge(sys.argv[1],Path(sys.argv[2]).resolve()),indent=2,sort_keys=True))


