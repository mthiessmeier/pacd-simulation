# Independent review on accepted main

All 86 focused tests passed on clean main at `d5a29699e14409bfd54d30c51117c81077639ee6`. The ten-attempt challenge passed and reproduced the approved PR challenge's observations. No blocking findings remain. Owner acceptance is recorded separately.

## Challenge results

The reviewer declared ten attempts before any diagnostic was run. The first read reported ten incomplete entries with null action counts. The reviewer then produced each condition in a private scratch workspace with ordinary bounded runner and retention controls.

| Attempt | Observation | Escalations | Candidates |
| --- | --- | ---: | ---: |
| original | COMPLETED | 1 | 3 |
| failed | FAILED | — | — |
| static | COMPLETED | 4 | 4 |
| timed-out | TIMED_OUT | — | — |
| not-started | INCOMPLETE | — | — |
| in-progress | INCOMPLETE | — | — |
| bad-receipt | INVALID | — | — |
| retry | COMPLETED | 1 | 1 |
| no-actions | COMPLETED | 0 | 0 |
| late-failure | FAILED | — | — |

Four of ten registered attempts completed. The reviewer matched actions by ID directly from raw events and independently counted eight candidates, one approval, six escalations, one prohibition, one simulated execution, one verified execution and zero prohibited executions. The zero-candidate completion produced observable zeros. A retry retained its own identity beside the earlier failure. The report withheld counts for a late failure even though the unfinished raw files contained an execution.

The challenge exercised an injected worker failure and the production timeout exception through the normal failure-retention path. It did not wait for the five-minute deadline. Changed seeds, mismatched and missing control records, a modified completed status, a rehashed false derived summary and a conflicting failure manifest all withheld the affected counts. Reusing an invocation with an orphaned receipt was refused before allocation. The dedicated workspace inventory was unchanged during report reads and refusals.

The script validates the main merge parents `9c9dfcec659870c41aa7cc95846d6760d9c31df7` and `9f58a43021eb1efe159a55b4540e0e872b963349`. The merged main and the approved second parent share tree `b8f84815f15aee2473ea2150820497777eb541b6`. The top-level README selects the implementation `5eb554c21b008038ecc50d0f7433977bef64ba7a`, differing from the accepted main only in README.md. Compared with the reviewed script, only its commit-identity guard changed. Both executions had the same register, raw-derived episode metrics, row order, statuses, reasons, refusals and invariant outcomes. Their normalized result digest is `798d0a865eff2102b142b963f95da4d3c9526891c255dadfa09e8f36e40ebe06`. It excludes the tested commit ID, per-run timestamped directory identities and the whole-report digest that binds those identities. New run IDs are expected across fresh invocations. Repeating the read of the same retained register reproduced the entire report.

## Reproduce

Set `$review` to the extracted independent evidence directory and run these commands from the accepted main checkout with the frozen environment installed by the gate instructions. The commands use a fresh local scratch directory. They do not write to the shared run, receipt or invocation stores. The challenge drives the CLI entry point in process, while the package's CLI replay uses standalone processes.

```powershell
$w = Join-Path $env:USERPROFILE 'PACD-Workspaces/PACD-Simulation'
$trial = Join-Path $w ('var/tmp/p2ir-' + [guid]::NewGuid().ToString('N').Substring(0,6))
New-Item -ItemType Directory -Path $trial | Out-Null
$env:TEMP = $trial
$env:TMP = $trial
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:HYPOTHESIS_STORAGE_DIRECTORY = Join-Path $trial 'hyp'
& ./.venv/Scripts/python.exe -B (Join-Path $review 'challenge.py') d5a29699e14409bfd54d30c51117c81077639ee6 (Join-Path $trial 'cases')
if ($LASTEXITCODE) { throw 'Independent challenge failed' }
& ./.venv/Scripts/python.exe -B -m pytest --basetemp (Join-Path $trial 'pytest') -p no:cacheprovider -q tests/scenario/test_registered_metrics.py tests/scenario/test_episode_metrics.py tests/unit/test_metrics_isolation.py tests/negative/test_invocation_receipts.py tests/reproducibility/test_diagnostic_replay.py
if ($LASTEXITCODE) { throw 'Focused tests failed' }
```

[Independent challenge outcome](challenge-results.json) · [Focused test output](pytest.txt)
