# PACD Phase 2 reviewer guide

**Start with the [merged evaluator README at df33295](https://github.com/mthiessmeier/pacd-simulation/blob/df33295469094a5ed9aa26fcc4b1fa1d019d3e5c/README.md#reconstruct-inside-the-bounded-workspace).** Its walkthrough checks out `d5a29699e14409bfd54d30c51117c81077639ee6`, the accepted Phase 2 work sample, and runs a small example on a CPU. The receipt identifies the README used and confirms that the fresh clone and run manifest both recorded `d5a2969`. [Post-merge walkthrough receipt](cli/post-merge-readme-walkthrough.json) · [Acceptance record](ACCEPTANCE.md) · [Increment history](PHASE2_HISTORY.md)

## What the work sample shows

Polymorphic Agentic Cyberdefense (PACD) asks how much authority a defender should have to act on what it observes. This Guarded Agency work sample makes one proposal traceable from its evidence through authorization to its effect on a simulated session. The evaluation harness owns the inputs and retained records. The defender proposes an action, the governor decides whether it can proceed, and the verifier checks what the in-memory broker actually changed. [Architecture and information boundaries](PHASE2_HISTORY.md)

At seed 424242 the repeated-reading fixture delivers two elevated readings for the same identity at tick 3. The planner waits through both. At tick 4 a fresh reading prompts a human-review proposal. The governor records `ESCALATE`. The broker executes nothing, and the verifier records the same pre- and post-state digest, beginning `bd2a68c85614`. At tick 5 the planner suppresses a duplicate referral. In the identity diagnostic, the governor approves a session isolation. The broker changes the state digest and the verifier confirms the expected effect. [Two action-to-state traces and retained summary evidence](cli/action-trace.json)

| Seed 424242, one episode per row | Candidates | Escalations | Simulated executions |
| --- | ---: | ---: | ---: |
| Identity smoke, original diagnostic with two configured probes | 3 | 1 | 1 |
| Identity smoke, PACD planner | 0 | 0 | 0 |
| Repeated readings, static review rule | 4 | 4 | 0 |
| Repeated readings, PACD planner | 1 | 1 | 0 |

The planner’s wait also has a cost. On identity smoke, the episode ended without the second elevated reading required for a referral. Human review is modeled as a pending escalation. Human review time and comparative safety remain unmeasured. [Case matrix](cli/matrix.md) · [Claims and limitations](CLAIMS.md)

## Which attempts count

In a separate eight-slot register, **3 of 8 attempts completed**. The remaining rows recorded one failed attempt, one timeout, two incomplete attempts and one invalid seed binding. The three verified episodes supplied **5 escalations among 7 candidates**, one simulated execution and zero prohibited executions. The other five rows withheld action counts. The mixed register deliberately exercises these outcomes; its completion fraction is a test observation. [Registered report](cli/mixed-register-report.json) · [Independent ten-slot challenge](independent/REVIEW.md)

## Reproduce from the accepted merge

To run the [packaged walkthrough](cli/accepted-main-walkthrough.ps1), start PowerShell in the extracted package root with private repository access, the designated PACD workspace, CPython 3.13.15, project-local uv 0.12.5 and the frozen package cache. Dot-source the script so the following commands reuse the checkout, run directory and register it creates. The walkthrough completes one of two declared slots, leaving the other unstarted.

```powershell
. .\cli\accepted-main-walkthrough.ps1
& $uv run --frozen --no-sync pacd-sim metrics --register $RegisterPath --register-sha256 $RegisterPin
& $uv run --frozen --no-sync python docs/application_demo/regenerate.py $Diagnostic.run_dir
```

The first command includes the environment doctor, prospective diagnostic, receipt verification and planner replay. The last command rebuilds the summary from retained raw events. In the post-merge README run, the checkout and manifest both recorded `d5a2969`. The register replay returned the same report, and the regenerated CSV and Parquet matched the accepted files byte-for-byte. [Post-merge verification on PR #10](https://github.com/mthiessmeier/pacd-simulation/pull/10#issuecomment-7068749905) · [Packaged walkthrough receipt](cli/accepted-main-smoke.json) · [Regeneration receipt](walkthrough-regeneration.json) · [Full CLI replay](cli/REPRODUCE.md)

The gate ledger and independent challenge support the engineering acceptance. All runs are labeled `NON_REPORTABLE_DIAGNOSTIC`. [Post-merge validation](ACCEPTANCE.md) · [Reproduce the gates](gates/REPRODUCE.md) · [Application wording](APPLICATION_WORDING.md)
