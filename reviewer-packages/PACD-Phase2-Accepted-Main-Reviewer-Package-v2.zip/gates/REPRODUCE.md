# Reproduce the accepted Phase 2 gates on main

Use a fresh checkout on the named main branch at the accepted merge recorded in the gate ledger. The ledger binds both merge parents and verifies that the merge tree equals the approved PR tree. The commit named in the top-level README has the same implementation. The subsequent approved commit changes only the README. Create two fresh project environments with the reviewed Windows CPython 3.13.15 runtime and project-local uv 0.12.5 cache. The installed package versions and lock match the approved PR head.

Set `$workspace` to the designated workspace and `$packet` to the extracted directory containing the runner and the store inventory script. Supply a fresh evidence directory and a fresh short temp path. Stop other writers to the retained run, receipt and invocation stores during the nine denial checks so the recorded inventory covers only those invocations.

```powershell
$ErrorActionPreference = 'Stop'
$identity = Get-Content (Join-Path $packet 'gates.json') -Raw | ConvertFrom-Json
if ((git rev-parse HEAD) -ne $identity.head -or (git branch --show-current) -ne $identity.branch -or (git status --porcelain)) {
    throw 'Clean named checkout at the accepted merge commit required'
}
if ((Test-Path -LiteralPath '.venv') -or $env:UV_PROJECT_ENVIRONMENT) {
    throw 'Use a fresh checkout without a pre-existing or redirected project environment'
}
$suffix = [guid]::NewGuid().ToString('N').Substring(0,6)
$evidence = Join-Path $workspace "review\phase2-accepted-gates-$suffix"
$short = Join-Path $workspace "t\p$suffix"
New-Item -ItemType Directory -Path $evidence,$short | Out-Null
$runner = Join-Path $packet 'run-gates.ps1'
foreach ($group in 'setup','denial','quality','coverage','reconstruction','focus','fixture','baseline','prospective','defender','planner','metrics','registered') {
    $env:UV_PROJECT_ENVIRONMENT = $null
    & $runner $group $workspace $evidence $short
}
& '.\.venv\Scripts\python.exe' -B (Join-Path $packet 'verify-rerun.py') $evidence
if ($LASTEXITCODE) { throw 'Gate results differ from the reviewed ledger' }
```

The smoke, maintenance and repeated-reading fixtures each exercise a reportable-mode request under the original diagnostic, the static rule and the stateful PACD planner. Each request must return exit 3. The runner fingerprints the names, types, sizes, modes, mtimes and content of all regular files across the three retained stores before and after the nine requests. The other gates include two independent frozen installations, two complete suites, branch-aware coverage, focused subsets including defender trace, static analysis, a fresh dependency audit and a comparison of secret-scanner fingerprints to the approved PR head. The [gate ledger](gates.json) contains the command arguments, exit codes, output hashes and suite totals. The [runner](run-gates.ps1) and [inventory script](store-inventory.py) reproduce the checks. The [rerun verifier](verify-rerun.py) checks the fresh results against the ledger and the [reviewed dependency list](advisories.json).

The README revision pin contains a Git commit ID. The [finding classification](secret-triage.json) records the exact file, line, token fingerprint and comparison with the approved PR head. The rerun verifier checks that attribution against the reviewed revision and the raw scanner output.
