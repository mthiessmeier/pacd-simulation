"""Compare a fresh gate run with the reviewed gate ledger."""

import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def require(passed, description):
    if not passed:
        raise SystemExit(f"Gate failed: {description}")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def scanner_fingerprint(path):
    rows = sorted(
        [name, finding["type"], finding["hashed_secret"]]
        for name, findings in read(path)["results"].items()
        for finding in findings
    )
    encoded = json.dumps(rows, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], text=True).strip()


def versions(roster):
    return sorted((dependency["name"], dependency.get("version")) for dependency in roster)


def main():
    packet = Path(__file__).resolve().parent
    evidence = Path(sys.argv[1])
    expected = read(packet / "gates.json")
    require(git("rev-parse", "HEAD") == expected["head"], "reviewed commit")
    require(git("rev-parse", "HEAD^{tree}") == expected["tree"], "reviewed tree")
    require(git("branch", "--show-current") == expected["branch"], "named branch")
    require(not git("status", "--porcelain"), "clean checkout")
    implementation = expected["implementation"]
    require(git("rev-list","--parents","-1","HEAD").split()[1:] == expected["parents"] ==
            [expected["accepted_base"],expected["parent_reviewed_head"]], "two exact merge parents")
    require(git("rev-parse","HEAD^2^{tree}") == expected["tree"], "approved PR tree equals accepted main")
    require(git("rev-parse","HEAD^2^1") == implementation, "implementation parent of the approved PR head")
    require(git("merge-base", expected["accepted_base"], "HEAD") == expected["accepted_base"], "accepted main base")
    require(git("diff", "--name-only", implementation, "HEAD") == "README.md", "documentation-only head")
    require(implementation in Path("README.md").read_text(encoding="utf-8"), "README evaluator pin")
    require(sha(Path("uv.lock")) == expected["lock_sha256"], "frozen lock")
    sync_logs = [(evidence / f"{name}.log").read_text(encoding="utf-8-sig")
                 for name in ("initial-offline-sync", "final-reconstruct")]
    locations = [re.search(r"(?m)^Creating virtual environment at: (.+)$", data) for data in sync_logs]
    require(all(locations) and locations[0][1] == ".venv" and
            Path(locations[1][1]).resolve() != Path(".venv").resolve(), "two fresh environments")
    rosters = [sorted(row.strip().split(" (from ")[0] for row in data.splitlines()
                      if row.startswith(" + ")) for data in sync_logs]
    reference = expected["frozen_environments"]
    require(rosters[0] == rosters[1] and len(rosters[0]) == reference["packages_including_project"]
            and hashlib.sha256("\n".join(rosters[0]).encode()).hexdigest() == reference["install_roster_sha256"],
            "matching installed package rosters")
    for name, details in expected["command_results"].items():
        record = read(evidence / f"{name}.json")
        require(record["exit"] == details["exit"], f"{name} exit")
        require(record["sha256"].lower() == sha(evidence / f"{name}.log"), f"{name} log")
    for name, counts in expected["suites"].items():
        output = (evidence / f"{name}.log").read_text(encoding="utf-8-sig")
        end = re.fullmatch(
            r"(\d+) passed(?:, (\d+) skipped)?(?:, \d+ deselected)? in .+", output.splitlines()[-1]
        )
        require(end is not None, f"{name} summary")
        require(int(end[1]) == counts["passed"] and int(end[2] or 0) == counts["skipped"], name)
        if counts["skipped"]:
            require("WinError 1314" in output, f"{name} expected Windows privilege skip")
    coverage = read(evidence / "coverage.json")
    require(coverage["totals"] == expected["coverage"], "overall branch coverage")
    for name, summary in expected["target_file_coverage"].items():
        require(coverage["files"][name]["summary"] == summary, f"coverage for {name}")
    for name in ("final-doctor", "final-reconstruction-doctor"):
        require(read(evidence / f"{name}.log")["passed"], f"{name} result")
    scenarios = {
        "smoke": "diagnostic_identity_smoke.yaml",
        "maintenance": "diagnostic_maintenance_window.yaml",
        "repeated": "diagnostic_repeated_readings.yaml",
    }
    conditions = {
        "original": "diagnostic_baseline.yaml",
        "static": "static_review.yaml",
        "planner": "pacd_corroborated_review.yaml",
    }
    for case, fixture in scenarios.items():
        for policy, descriptor in conditions.items():
            name = f"{policy}-{case}-denial"
            args = read(evidence / f"{name}.json")["arguments"]
            require(args[args.index("--scenario") + 1] == f"configs/scenarios/{fixture}", name)
            require(args[args.index("--baseline") + 1] == f"configs/defenders/{descriptor}", name)
            require(args.count("--reportable") == 1 and args[args.index("--seed") + 1] == "424242", name)
            item = read(evidence / f"{name}.log")
            require(item["status"] == "DENIED" and not item["valid"] and not item["reportable"], name)
            require(item["reason"] == "Author approval record is absent or not a regular file", name)
    require(
        read(evidence / "store-before.log") == read(evidence / "store-after.log"), "store identity"
    )
    denial = read(evidence / "denial-inventory.json")
    require(denial["before"] == denial["after"] and denial["name_changes"] == 0, "store inventory")
    require(not denial["approval_present"] and denial["requests"] == 9, "reportable denials")
    audit = read(evidence / "advisories.json")["dependencies"]
    prior = read(packet / "advisories.json")["dependencies"]
    require(versions(audit) == versions(prior), "audited dependency versions")
    require(
        [d["name"] for d in audit if d.get("skip_reason")] == ["pacd-simulation"], "audit scope"
    )
    require(not any(d.get("vulns") for d in audit), "dependency advisories")
    require(
        scanner_fingerprint(evidence / "final-secrets.log")
        == expected["secret_fingerprint_sha256"],
        "secret scanner fingerprints",
    )
    triage = expected["secret_scan_triage"]
    fingerprint = hashlib.sha1(implementation.encode("ascii")).hexdigest()
    bucket = read(evidence / "final-secrets.log")["results"]["README.md"]
    hits = [hit for hit in bucket if hit["type"] == "Hex High Entropy String" and hit["hashed_secret"] == fingerprint]
    require(len(hits) == 1 and fingerprint == triage["scanner_fingerprint"], "README pin finding")
    line = hits[0]["line_number"]
    require(line == triage["line"] and Path("README.md").read_text(encoding="utf-8").splitlines()[line - 1].strip()
            == f"$Revision = '{implementation}'", "README pin classification")
    print(
        f"Verified {len(expected['command_results'])} receipts, both suites, coverage, "
        "nine denials, audit and scanner fingerprints."
    )


if __name__ == "__main__":
    main()
