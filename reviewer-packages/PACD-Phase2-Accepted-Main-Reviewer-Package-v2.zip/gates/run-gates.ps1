param([string]$Group, [string]$WorkspaceRoot, [string]$evDir, [string]$short)
$ErrorActionPreference='Stop'
$uv = Join-Path $WorkspaceRoot 'var\cache\tools\uv\0.12.5\uv.exe'
$env:PATH = "$(Split-Path -Parent $uv);$env:PATH"
$env:UV_CACHE_DIR = Join-Path $WorkspaceRoot 'var\cache\uv-project'
$env:UV_PYTHON_DOWNLOADS = 'never'
$env:TMP = $short
$env:TEMP = $short
$env:PYTHONUTF8='1'
$env:HYPOTHESIS_STORAGE_DIRECTORY = Join-Path $short ('hyp-' + $Group)
$env:MPLCONFIGDIR = Join-Path $short ('mpl-' + $Group)
$env:PIP_CACHE_DIR = Join-Path $short 'pipcache'
$env:PIP_DISABLE_PIP_VERSION_CHECK='1'
function Invoke-Gate([string]$name, [string[]]$argv, [int[]]$expected=@(0)) {
  $log=Join-Path $evDir "$name.log"
  if (Test-Path -LiteralPath $log) {throw "Gate $name already ran"}
  $start=Get-Date -Format o
  & $uv @argv *> $log
  $rc=$LASTEXITCODE
  [ordered]@{name=$name;exe=$uv;arguments=$argv;cwd=(Get-Location).Path;started=$start;ended=(Get-Date -Format o);exit=$rc;sha256=(Get-FileHash $log).Hash} | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8NoBOM -LiteralPath (Join-Path $evDir "$name.json")
  Write-Host "$name exit $rc"
  if ($rc -notin $expected) {throw "Unexpected exit $rc for $name"}
}
$use=@('run','--frozen','--no-sync')
switch($Group) {
  'setup' { Invoke-Gate 'initial-offline-sync' @('sync','--frozen','--offline','--python','3.13.15') }
  'quality' {
    Invoke-Gate 'final-lock' @('lock','--check','--offline','--no-cache','--prerelease','disallow')
    Invoke-Gate 'final-doctor' ($use+@('pacd-sim','doctor','--workspace-root',$WorkspaceRoot))
    Invoke-Gate 'final-format' ($use+@('ruff','format','--check','.','--no-cache'))
    Invoke-Gate 'final-lint' ($use+@('ruff','check','.','--no-cache'))
    Invoke-Gate 'final-mypy' ($use+@('mypy','src','tests','docs/application_demo/regenerate.py','--no-incremental','--cache-dir',"$short\my2"))
    Invoke-Gate 'final-bandit' ($use+@('bandit','-c','pyproject.toml','-r','src'))
    Invoke-Gate 'final-secrets' ($use+@('detect-secrets','scan','--no-verify','.'))
    Invoke-Gate 'audit' ($use+@('pip-audit','--local','--skip-editable','--cache-dir',"$short\audit2",'-f','json','-o',"$evDir\advisories.json")) @(0,1)
  }
  'coverage' {
    $env:COVERAGE_FILE=Join-Path $short '.coverage-reviewed'
    $bt=Join-Path $WorkspaceRoot ('t\i1c'+[guid]::NewGuid().ToString('N').Substring(0,4))
    if (Test-Path $bt) {throw 'Test temp collision'}
    Invoke-Gate 'final-pytest-coverage' ($use+@('pytest','-p','no:cacheprovider','--basetemp',$bt,'-q','--cov=pacd_sim','--cov-branch','--cov-report=term-missing',"--cov-report=json:$evDir\coverage.json","--cov-report=html:$evDir\coverage-html"))
  }
  'reconstruction' {
    $env:UV_PROJECT_ENVIRONMENT=Join-Path $short ('v'+[guid]::NewGuid().ToString('N').Substring(0,6))
    if (Test-Path $env:UV_PROJECT_ENVIRONMENT) {throw 'Requires new environment'}
    Invoke-Gate 'final-reconstruct' @('sync','--frozen','--offline','--python','3.13.15')
    Invoke-Gate 'final-reconstruction-doctor' ($use+@('pacd-sim','doctor','--workspace-root',$WorkspaceRoot))
    $bt=Join-Path $WorkspaceRoot ('t\i1r'+[guid]::NewGuid().ToString('N').Substring(0,4))
    if (Test-Path $bt) {throw 'Test temp collision'}
    Invoke-Gate 'final-suite-reconstructed' ($use+@('pytest','-p','no:cacheprovider','--basetemp',$bt,'-q'))
  }
  'focus' {
    $bt=Join-Path $WorkspaceRoot ('t\i1f'+[guid]::NewGuid().ToString('N').Substring(0,4))
    if (Test-Path $bt) {throw 'Test temp collision'}
    Invoke-Gate 'final-focused' ($use+@('pytest','-p','no:cacheprovider','--basetemp',$bt,'-q','tests/scenario/test_verified_event_sequence.py','tests/reproducibility/test_verified_regeneration.py','tests/reproducibility/test_diagnostic_replay.py','tests/negative/test_identity_assurance_contract.py'))
  }
  'fixture' {
    $bt=Join-Path $WorkspaceRoot ('t\i3m'+[guid]::NewGuid().ToString('N').Substring(0,6))
    if (Test-Path $bt) {throw 'Test temp collision'}
    Invoke-Gate 'maintenance-focused' ($use+@('pytest','-p','no:cacheprovider','--basetemp',$bt,'-q','tests/scenario/test_second_scripted_scenario.py','tests/reproducibility/test_diagnostic_replay.py::test_manifest_cannot_substitute_the_selected_script','tests/unit/test_governed_configuration.py::test_configuration_check_validates_the_second_governed_scenario'))
  }
  'baseline' {
    $bt=Join-Path $WorkspaceRoot ('t\b4f'+[guid]::NewGuid().ToString('N').Substring(0,6))
    if (Test-Path $bt) {throw 'Test temp collision'}
    Invoke-Gate 'baseline-focused' ($use+@('pytest','-p','no:cacheprovider','--basetemp',$bt,'-q','tests/scenario/test_static_baseline.py','tests/unit/test_defender_contract_and_boundaries.py'))
  }
  'prospective' {
    $bt=Join-Path $WorkspaceRoot ('t\p4f'+[guid]::NewGuid().ToString('N').Substring(0,6))
    if(Test-Path $bt){throw 'Test temp collision'}
    Invoke-Gate 'prospective-focused' ($use+@('pytest','-p','no:cacheprovider','--basetemp',$bt,'-q','tests/scenario/test_prospective_static.py'))
  }
  'defender' {
    $bt=Join-Path $WorkspaceRoot ('t\d5f'+[guid]::NewGuid().ToString('N').Substring(0,6))
    if(Test-Path $bt){throw 'Test temp collision'}
    Invoke-Gate 'defender-focused' ($use+@('pytest','-p','no:cacheprovider','--basetemp',$bt,'-q','tests/scenario/test_defender_trace.py'))
  }
  'planner' {
    $bt=Join-Path $WorkspaceRoot ('t\p5g' + [guid]::NewGuid().ToString('N').Substring(0,6))
    if (Test-Path -LiteralPath $bt) {throw 'Test temp collision'}
    Invoke-Gate 'planner-focused' ($use+@('pytest','-p','no:cacheprovider','--basetemp',$bt,'-q','tests/scenario/test_prospective_planner.py'))
  }
  'metrics' {
    $bt=Join-Path $WorkspaceRoot ('t\i6m'+[guid]::NewGuid().ToString('N').Substring(0,6))
    if(Test-Path $bt){throw 'Test temp collision'}
    Invoke-Gate 'metrics-focused' ($use+@('pytest','-p','no:cacheprovider','--basetemp',$bt,'-q','tests/scenario/test_episode_metrics.py'))
  }
  'registered' {
    $bt=Join-Path $WorkspaceRoot ('t\i6a'+[guid]::NewGuid().ToString('N').Substring(0,6))
    if(Test-Path $bt){throw 'Test temp collision'}
    Invoke-Gate 'registered-focused' ($use+@('pytest','-p','no:cacheprovider','--basetemp',$bt,'-q','tests/scenario/test_registered_metrics.py'))
  }
  'denial' {
    if (Test-Path 'configs/protocol/frozen/APPROVAL.json') {throw 'Unexpected approval'}
    function Inventory { @(foreach($store in @('runs','receipts','invocations')) {Get-ChildItem -LiteralPath "$WorkspaceRoot\var\$store" -Force|ForEach-Object {"$store/$($_.Name)"}}) | Sort-Object }
    $before=Inventory
    Invoke-Gate 'store-before' ($use+@('python',(Join-Path $PSScriptRoot 'store-inventory.py'),$WorkspaceRoot))
    $scenarios = [ordered]@{smoke='diagnostic_identity_smoke.yaml';maintenance='diagnostic_maintenance_window.yaml';repeated='diagnostic_repeated_readings.yaml'}
    $conditions = [ordered]@{original='diagnostic_baseline.yaml';static='static_review.yaml';planner='pacd_corroborated_review.yaml'}
    $requests = 0
    foreach ($condition in $conditions.GetEnumerator()) {
        foreach ($scenario in $scenarios.GetEnumerator()) {
            $name = "$($condition.Key)-$($scenario.Key)-denial"
            $argsForRun = $use+@('pacd-sim','diagnostic','--workspace-root',$WorkspaceRoot,'--seed','424242','--reportable',
                '--scenario',('configs/scenarios/'+$scenario.Value),'--baseline',('configs/defenders/'+$condition.Value))
            Invoke-Gate $name $argsForRun @(3)
            $denied = Get-Content -LiteralPath (Join-Path $evDir "$name.log") -Raw | ConvertFrom-Json
            if ($denied.status -ne 'DENIED' -or $denied.valid -or $denied.reportable -or
                $denied.reason -ne 'Author approval record is absent or not a regular file') {
                throw "Unexpected reportability response for $name"
            }
            $requests++
        }
    }
    Invoke-Gate 'store-after' ($use+@('python',(Join-Path $PSScriptRoot 'store-inventory.py'),$WorkspaceRoot))
    $fingerprint=Get-Content -Raw "$evDir\store-before.log" | ConvertFrom-Json
    $end=Get-Content -Raw "$evDir\store-after.log" | ConvertFrom-Json
    if($fingerprint.sha256 -ne $end.sha256 -or $fingerprint.entries -ne $end.entries -or $fingerprint.files -ne $end.files){throw 'Control store contents or metadata changed'}
    $after=Inventory
    $changes=@(Compare-Object $before $after).Count
    [ordered]@{exit=3;before=$before.Count;after=$after.Count;name_changes=$changes;recursive_fingerprint=$fingerprint;requests=$requests;approval_present=(Test-Path 'configs/protocol/frozen/APPROVAL.json')}|ConvertTo-Json -Depth 4|Set-Content "$evDir\denial-inventory.json" -Encoding utf8NoBOM
    if ($changes) {throw 'Inventory changed'}
  }
  'demo' {
    foreach($entry in @(@('first',424242),@('replay',424242),@('alternate',424243))) {
      $name=$entry[0]
      Invoke-Gate "final-$name" ($use+@('pacd-sim','diagnostic','--workspace-root',$WorkspaceRoot,'--seed',[string]$entry[1]))
      $run=(Get-Content -Raw "$evDir\final-$name.log"|ConvertFrom-Json).run_dir
      Invoke-Gate "verify-$name" ($use+@('pacd-sim','verify',$run,'--workspace-root',$WorkspaceRoot))
    }
    $run=(Get-Content -Raw "$evDir\final-first.log"|ConvertFrom-Json).run_dir
    Invoke-Gate 'final-regenerate' ($use+@('python','docs/application_demo/regenerate.py',$run))
  }
}
